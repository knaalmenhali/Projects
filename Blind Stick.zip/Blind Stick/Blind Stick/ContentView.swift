//
//  ContentView.swift
//  Blind Stick
//
//  Created by smrc on 3/19/25.
//

import SwiftUI

import UIKit
import FirebaseAuth
import FirebaseCore
import FirebaseFirestore

struct ContentView: View {
    @AppStorage("isLoggedIn") private var isLoggedIn = false
    
    var body: some View {
        if isLoggedIn {
            MainTabView()
        } else {
            AuthView()
        }
    }
}

#Preview {
    ContentView()
}










