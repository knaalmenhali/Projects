//
//  AuthView.swift
//  Blind Stick
//

import SwiftUI
import UIKit
import FirebaseAuth
import FirebaseCore
import FirebaseFirestore

struct AuthView: View {
    @State private var showLogin = true
    
    var body: some View {
        VStack {
            Image(systemName: "waveform.path.ecg")
                .resizable()
                .scaledToFit()
                .frame(width: 100, height: 100)
                .foregroundColor(.blue)
            
            Text("SensorSafe")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            if showLogin {
                LoginView()
            } else {
                SignupView()
            }
            
            Button(action: {
                withAnimation {
                    showLogin.toggle()
                }
            }) {
                Text(showLogin ? "Don't have an account? Sign Up" : "Already have an account? Login")
                    .foregroundColor(.blue)
            }
            .padding()
        }
        .padding()
    }
}
