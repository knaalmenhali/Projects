//
//  EmergencyContactsView.swift
//  Blind Stick
//

import SwiftUI
import UIKit
import FirebaseAuth
import FirebaseCore
import FirebaseFirestore

struct EmergencyContact: Identifiable, Codable {
    var id: String = UUID().uuidString
    var name: String
    var phoneNumber: String
    var relationship: String
}

class EmergencyContactsViewModel: ObservableObject {
    @Published var contacts: [EmergencyContact] = []
    private var db = Firestore.firestore()
    
    func fetchContacts() {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        db.collection("users").document(userId).collection("emergencyContacts")
            .getDocuments { [weak self] snapshot, error in
                guard let documents = snapshot?.documents else {
                    print("Error fetching contacts: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                
                let contacts = documents.compactMap { doc -> EmergencyContact? in
                    let data = doc.data()
                    return EmergencyContact(
                        id: doc.documentID,
                        name: data["name"] as? String ?? "",
                        phoneNumber: data["phoneNumber"] as? String ?? "",
                        relationship: data["relationship"] as? String ?? ""
                    )
                }
                
                DispatchQueue.main.async {
                    self?.contacts = contacts
                }
            }
    }
    
    func addContact(_ contact: EmergencyContact, completion: @escaping (Bool) -> Void) {
        guard let userId = Auth.auth().currentUser?.uid else {
            completion(false)
            return
        }
        
        let contactData: [String: Any] = [
            "name": contact.name,
            "phoneNumber": contact.phoneNumber,
            "relationship": contact.relationship
        ]
        
        db.collection("users").document(userId).collection("emergencyContacts").addDocument(data: contactData) { [weak self] error in
            if let error = error {
                print("Error adding contact: \(error.localizedDescription)")
                completion(false)
                return
            }
            
            self?.fetchContacts()
            completion(true)
        }
    }
    
    func deleteContact(at offsets: IndexSet) {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        for index in offsets {
            let contact = contacts[index]
            db.collection("users").document(userId).collection("emergencyContacts").document(contact.id).delete { [weak self] error in
                if let error = error {
                    print("Error deleting contact: \(error.localizedDescription)")
                    return
                }
                
                DispatchQueue.main.async {
                    self?.contacts.remove(at: index)
                }
            }
        }
    }
}

struct EmergencyContactsView: View {
    @StateObject private var viewModel = EmergencyContactsViewModel()
    @State private var showingAddContact = false
    
    var body: some View {
        NavigationView {
            VStack {
                if viewModel.contacts.isEmpty {
                    VStack(spacing: 20) {
                        Image(systemName: "phone.bubble.left")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80, height: 80)
                            .foregroundColor(.gray)
                        
                        Text("No emergency contacts yet")
                            .font(.headline)
                        
                        Text("Add contacts who should be called in case of emergency")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        Button(action: {
                            showingAddContact = true
                        }) {
                            Text("Add Your First Contact")
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(8)
                        }
                    }
                    .padding()
                } else {
                    List {
                        ForEach(viewModel.contacts) { contact in
                            EmergencyContactRow(contact: contact)
                        }
                        .onDelete(perform: viewModel.deleteContact)
                    }
                }
            }
            .navigationTitle("Emergency Contacts")
            .navigationBarItems(trailing: Button(action: {
                showingAddContact = true
            }) {
                Image(systemName: "plus")
            })
            .sheet(isPresented: $showingAddContact) {
                AddEmergencyContactView(viewModel: viewModel)
            }
            .onAppear {
                viewModel.fetchContacts()
            }
        }
    }
}

struct EmergencyContactRow: View {
    let contact: EmergencyContact
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(contact.name)
                    .font(.headline)
                
                Text(contact.relationship)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Text(contact.phoneNumber)
                    .font(.subheadline)
            }
            
            Spacer()
            
            Button(action: {
                guard let url = URL(string: "tel://\(contact.phoneNumber.filter { $0.isNumber })") else { return }
                UIApplication.shared.open(url)
            }) {
                Image(systemName: "phone.fill")
                    .foregroundColor(.green)
                    .frame(width: 44, height: 44)
                    .background(Color(.systemGray6))
                    .clipShape(Circle())
            }
        }
        .padding(.vertical, 4)
    }
}

struct AddEmergencyContactView: View {
    @ObservedObject var viewModel: EmergencyContactsViewModel
    @Environment(\.presentationMode) var presentationMode
    @State private var name = ""
    @State private var phoneNumber = ""
    @State private var relationship = ""
    @State private var errorMessage = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Contact Information")) {
                    TextField("Full Name", text: $name)
                    TextField("Phone Number", text: $phoneNumber)
                        .keyboardType(.phonePad)
                    TextField("Relationship", text: $relationship)
                }
                
                if !errorMessage.isEmpty {
                    Section {
                        Text(errorMessage)
                            .foregroundColor(.red)
                    }
                }
                
                Section {
                    Button("Save Contact") {
                        saveContact()
                    }
                    .disabled(name.isEmpty || phoneNumber.isEmpty)
                }
            }
            .navigationTitle("Add Emergency Contact")
            .navigationBarItems(trailing: Button("Cancel") {
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
    
    func saveContact() {
        // Validate
        if name.isEmpty || phoneNumber.isEmpty {
            errorMessage = "Name and phone number are required"
            return
        }
        
        // Create new contact
        let newContact = EmergencyContact(
            name: name,
            phoneNumber: phoneNumber,
            relationship: relationship
        )
        
        // Add to Firebase
        viewModel.addContact(newContact) { success in
            if success {
                presentationMode.wrappedValue.dismiss()
            } else {
                errorMessage = "Failed to save contact. Please try again."
            }
        }
    }
}
