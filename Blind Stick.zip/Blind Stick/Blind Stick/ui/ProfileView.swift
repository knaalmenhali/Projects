//
//  ProfileView.swift
//  Blind Stick
//

import SwiftUI
import UIKit
import FirebaseAuth
import FirebaseCore
import FirebaseFirestore

struct UserProfile: Identifiable, Codable {
    var id: String = UUID().uuidString
    var fullName: String = ""
    var email: String = ""
    var phoneNumber: String = ""
    var bloodGroup: String = ""
    var emergencyContacts: [EmergencyContact] = []
}

class ProfileViewModel: ObservableObject {
    @Published var profile: UserProfile = UserProfile()
    private var db = Firestore.firestore()
    
    func fetchProfile() {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        db.collection("users").document(userId).getDocument { [weak self] snapshot, error in
            guard let data = snapshot?.data() else {
                print("Error fetching profile: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            DispatchQueue.main.async {
                self?.profile = UserProfile(
                    id: userId,
                    fullName: data["fullName"] as? String ?? "",
                    email: data["email"] as? String ?? "",
                    phoneNumber: data["phoneNumber"] as? String ?? "",
                    bloodGroup: data["bloodGroup"] as? String ?? ""
                )
            }
        }
    }
    
    func updateProfile(_ updatedProfile: UserProfile, completion: @escaping (Bool) -> Void) {
        guard let userId = Auth.auth().currentUser?.uid else {
            completion(false)
            return
        }
        
        let profileData: [String: Any] = [
            "fullName": updatedProfile.fullName,
            "email": updatedProfile.email,
            "phoneNumber": updatedProfile.phoneNumber,
            "bloodGroup": updatedProfile.bloodGroup
        ]
        
        db.collection("users").document(userId).updateData(profileData) { [weak self] error in
            if let error = error {
                print("Error updating profile: \(error.localizedDescription)")
                completion(false)
                return
            }
            
            DispatchQueue.main.async {
                self?.profile = updatedProfile
                completion(true)
            }
        }
    }
}


struct ProfileView: View {
    @StateObject private var viewModel = ProfileViewModel()
    @State private var showingEditProfile = false
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Personal Information")) {
                    HStack {
                        Text("Name")
                        Spacer()
                        Text(viewModel.profile.fullName)
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Email")
                        Spacer()
                        Text(viewModel.profile.email)
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Phone")
                        Spacer()
                        Text(viewModel.profile.phoneNumber.isEmpty ? "Not set" : viewModel.profile.phoneNumber)
                            .foregroundColor(.secondary)
                    }
                }
                
                Section(header: Text("Medical Information")) {
                    HStack {
                        Text("Blood Group")
                        Spacer()
                        Text(viewModel.profile.bloodGroup.isEmpty ? "Not set" : viewModel.profile.bloodGroup)
                            .foregroundColor(.secondary)
                    }
                }
                
                Section {
                    Button(action: {
                        showingEditProfile = true
                    }) {
                        Text("Edit Profile")
                    }
                }
                
                Section {
                    Button(action: logout) {
                        Text("Logout")
                            .foregroundColor(.red)
                    }
                }
            }
            .navigationTitle("Profile")
            .sheet(isPresented: $showingEditProfile) {
                EditProfileView(viewModel: viewModel)
            }
            .onAppear {
                viewModel.fetchProfile()
            }
        }
    }
    
    func logout() {
        do {
            try Auth.auth().signOut()
            UserDefaults.standard.set(false, forKey: "isLoggedIn")
        } catch {
            print("Error signing out: \(error.localizedDescription)")
        }
    }
}

struct EditProfileView: View {
    @ObservedObject var viewModel: ProfileViewModel
    @Environment(\.presentationMode) var presentationMode
    
    @State private var fullName: String = ""
    @State private var phoneNumber: String = ""
    @State private var bloodGroup: String = ""
    @State private var errorMessage: String = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Personal Information")) {
                    TextField("Full Name", text: $fullName)
                    TextField("Phone Number", text: $phoneNumber)
                        .keyboardType(.phonePad)
                }
                
                Section(header: Text("Medical Information")) {
                    Picker("Blood Group", selection: $bloodGroup) {
                        Text("Not specified").tag("")
                        Text("A+").tag("A+")
                        Text("A-").tag("A-")
                        Text("B+").tag("B+")
                        Text("B-").tag("B-")
                        Text("AB+").tag("AB+")
                        Text("AB-").tag("AB-")
                        Text("O+").tag("O+")
                        Text("O-").tag("O-")
                    }
                }
                
                if !errorMessage.isEmpty {
                    Section {
                        Text(errorMessage)
                            .foregroundColor(.red)
                    }
                }
                
                Section {
                    Button("Save Profile") {
                        saveProfile()
                    }
                }
            }
            .navigationTitle("Edit Profile")
            .navigationBarItems(trailing: Button("Cancel") {
                presentationMode.wrappedValue.dismiss()
            })
            .onAppear {
                loadCurrentProfile()
            }
        }
    }
    
    func loadCurrentProfile() {
        fullName = viewModel.profile.fullName
        phoneNumber = viewModel.profile.phoneNumber
        bloodGroup = viewModel.profile.bloodGroup
    }
    
    func saveProfile() {
        let updatedProfile = UserProfile(
            id: viewModel.profile.id,
            fullName: fullName,
            email: viewModel.profile.email,
            phoneNumber: phoneNumber,
            bloodGroup: bloodGroup,
            emergencyContacts: viewModel.profile.emergencyContacts
        )
        
        viewModel.updateProfile(updatedProfile) { success in
            if success {
                presentationMode.wrappedValue.dismiss()
            } else {
                errorMessage = "Failed to update profile. Please try again."
            }
        }
    }
}
