//
//  SignupView.swift
//  Blind Stick
//
//  Created by smrc on 3/19/25.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct SignupView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var fullName = ""
    @State private var errorMessage = ""
    @AppStorage("isLoggedIn") private var isLoggedIn = false
    @AppStorage("userId") private var userId = ""
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Create Account")
                .font(.title)
                .fontWeight(.bold)
            
            TextField("Full Name", text: $fullName)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
            
            TextField("Email", text: $email)
                .keyboardType(.emailAddress)
                .autocapitalization(.none)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
            
            SecureField("Password", text: $password)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
            
            SecureField("Confirm Password", text: $confirmPassword)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
            
            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .font(.caption)
            }
            
            Button(action: signupUser) {
                Text("Sign Up")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(8)
            }
        }
    }
    
    func signupUser() {
        errorMessage = ""
        
        if password != confirmPassword {
            errorMessage = "Passwords do not match"
            return
        }
        
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                errorMessage = error.localizedDescription
                return
            }
            
            if let user = result?.user {
                let newProfile = UserProfile(fullName: fullName, email: email)
                let db = Firestore.firestore()
                db.collection("users").document(user.uid).setData([
                    "fullName": newProfile.fullName,
                    "email": newProfile.email,
                    "phoneNumber": "",
                    "bloodGroup": ""
                ]) { error in
                    if let error = error {
                        errorMessage = error.localizedDescription
                        return
                    }
                    
                    userId = user.uid
                    isLoggedIn = true
                }
            }
        }
    }
}

#Preview {
    SignupView()
}
