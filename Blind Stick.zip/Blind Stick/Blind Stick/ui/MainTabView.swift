//
//  MainTabView.swift
//  Blind Stick
//
import SwiftUI

struct MainTabView: View {
    
    var body: some View {
        TabView {
            HomePageView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            
            EmergencyContactsView()
                .tabItem {
                    Label("Emergency", systemImage: "phone.fill")
                }
            
            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.fill")
                }
        }
    }
}

#Preview {
    MainTabView()
}
