//
//  HomeView.swift
//  Blind Stick
//

import SwiftUI
import FirebaseAuth
import FirebaseDatabase

struct SensorData: Codable {
    var alerts: Alerts
    var sensors: Sensors
    
    struct Alerts: Codable {
        var buttonAlert: Bool
    }
    
    struct Sensors: Codable {
        var acceleration: Acceleration
        var distance: Double
        var gyroscope: Gyroscope
        var waterLevel: Int
        
        struct Acceleration: Codable {
            var ax: Int
            var ay: Int
            var az: Int
        }
        
        struct Gyroscope: Codable {
            var gx: Int
            var gy: Int
            var gz: Int
        }
    }
}

class SensorViewModel: ObservableObject {
    @Published var sensorData: SensorData?
    @Published var isLoading = true
    @Published var errorMessage: String?
    
    private var ref: DatabaseReference
    
    init() {
        ref = Database.database().reference()
        fetchData()
    }
    
    func fetchData() {
        isLoading = true
        
        ref.observe(.value) { snapshot in
            self.isLoading = false
            
            guard let value = snapshot.value as? [String: Any] else {
                self.errorMessage = "Data format error"
                return
            }
            
            do {
                let jsonData = try JSONSerialization.data(withJSONObject: value)
                let decodedData = try JSONDecoder().decode(SensorData.self, from: jsonData)
                
                DispatchQueue.main.async {
                    self.sensorData = decodedData
                }
            } catch {
                self.errorMessage = "Failed to decode data: \(error.localizedDescription)"
            }
        }
    }
    
    var shouldShowAlarm: Bool {
        guard let data = sensorData else { return false }
        
        return data.alerts.buttonAlert ||
               data.sensors.distance < 10 ||
               data.sensors.waterLevel > 200 ||
               data.sensors.acceleration.ax > 5000
    }
}


struct HomePageView: View {
    @StateObject private var sensorViewModel = SensorViewModel()
    @StateObject private var contactsViewModel = EmergencyContactsViewModel()
    @State private var emergencyMode = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    StatusCardView(sensorViewModel: sensorViewModel)
                    
                    EmergencyButtonView(
                        emergencyMode: $emergencyMode,
                        contacts: contactsViewModel.contacts
                    )
                    
                    SensorReadingsView(sensorViewModel: sensorViewModel)
                }
                .padding()
            }
            .background(Color(.systemGray6).ignoresSafeArea())
            .navigationTitle("Blind Stick")
            .overlay(
                Group {
                    if emergencyMode {
                        EmergencyModeView(
                            isActive: $emergencyMode,
                            contacts: contactsViewModel.contacts
                        )
                    }
                }
            )
        }
        .onAppear {
            sensorViewModel.fetchData()
            contactsViewModel.fetchContacts()
        }
    }
}

struct StatusCardView: View {
    @ObservedObject var sensorViewModel: SensorViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: sensorViewModel.shouldShowAlarm ? "exclamationmark.triangle.fill" : "checkmark.circle.fill")
                    .font(.title)
                    .foregroundColor(sensorViewModel.shouldShowAlarm ? .red : .green)
                
                Text(sensorViewModel.shouldShowAlarm ? "Alert Detected" : "System Normal")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Spacer()
                
                if sensorViewModel.isLoading {
                    ProgressView()
                }
            }
            
            if sensorViewModel.shouldShowAlarm {
                Text(getAlertMessage(data: sensorViewModel.sensorData))
                    .foregroundColor(.red)
                    .font(.subheadline)
                    .padding(.top, 4)
            } else {
                Text("All sensors operating within normal parameters")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding(.top, 4)
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        )
    }
    
    func getAlertMessage(data: SensorData?) -> String {
        guard let data = data else { return "Unknown alert" }
        
        var messages: [String] = []
        
        if data.alerts.buttonAlert {
            messages.append("Emergency button pressed")
        }
        
        if data.sensors.distance < 10 {
            messages.append("Obstacle too close (\(String(format: "%.1f", data.sensors.distance)) units)")
        }
        
        if data.sensors.waterLevel > 200 {
            messages.append("Water detected")
        }
        
        if data.sensors.acceleration.ax > 5000 {
            messages.append("Unusual movement detected")
        }
        
        return messages.joined(separator: ", ")
    }
}

struct EmergencyButtonView: View {
    @Binding var emergencyMode: Bool
    let contacts: [EmergencyContact]
    @State private var isPressed = false
    
    var body: some View {
        VStack(spacing: 12) {
            Button(action: {
                withAnimation {
                    isPressed = true
                    
                    let generator = UINotificationFeedbackGenerator()
                    generator.notificationOccurred(.warning)
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        isPressed = false
                        emergencyMode = true
                    }
                }
            }) {
                VStack {
                    Image(systemName: "sos")
                        .font(.system(size: 40))
                        .padding()
                    
                    Text("Emergency")
                        .font(.headline)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 20)
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(Color.red)
                        .shadow(color: Color.red.opacity(0.3), radius: 10, x: 0, y: 5)
                )
                .foregroundColor(.white)
                .scaleEffect(isPressed ? 0.95 : 1.0)
            }
            
            Text("Press for immediate assistance")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}
struct SensorReadingsView: View {
    @ObservedObject var sensorViewModel: SensorViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Sensor Readings")
                .font(.headline)
                .padding(.leading, 4)
            
            if sensorViewModel.isLoading {
                HStack {
                    Spacer()
                    ProgressView("Loading sensor data...")
                    Spacer()
                }
                .padding()
            } else if let data = sensorViewModel.sensorData {
                SensorItemView(
                    title: "Distance",
                    value: String(format: "%.1f", data.sensors.distance),
                    unit: "cm",
                    systemImage: "ruler",
                    color: data.sensors.distance < 10 ? .red : .blue,
                    isAlert: data.sensors.distance < 10
                )
                
                SensorItemView(
                    title: "Water Level",
                    value: "\(data.sensors.waterLevel)",
                    unit: "",
                    systemImage: "drop.fill",
                    color: data.sensors.waterLevel > 200 ? .red : .blue,
                    isAlert: data.sensors.waterLevel > 200
                )
                
                SensorItemView(
                    title: "Acceleration X",
                    value: "\(data.sensors.acceleration.ax)",
                    unit: "mg",
                    systemImage: "arrow.left.and.right",
                    color: data.sensors.acceleration.ax > 5000 ? .red : .blue,
                    isAlert: data.sensors.acceleration.ax > 5000
                )
                
                SensorItemView(
                    title: "Alert Button",
                    value: data.alerts.buttonAlert ? "Activated" : "Normal",
                    unit: "",
                    systemImage: "button.programmable",
                    color: data.alerts.buttonAlert ? .red : .blue,
                    isAlert: data.alerts.buttonAlert
                )
            } else if let error = sensorViewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .padding()
            }
        }
    }
}

struct SensorItemView: View {
    let title: String
    let value: String
    let unit: String
    let systemImage: String
    let color: Color
    let isAlert: Bool
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: systemImage)
                .font(.system(size: 22))
                .foregroundColor(.white)
                .frame(width: 44, height: 44)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(color)
                )
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                HStack(alignment: .firstTextBaseline, spacing: 4) {
                    Text(value)
                        .font(.headline)
                        .foregroundColor(isAlert ? .red : .primary)
                    
                    if !unit.isEmpty {
                        Text(unit)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    if isAlert {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(.red)
                            .font(.caption)
                    }
                }
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.05), radius: 2, x: 0, y: 1)
        )
    }
}

struct EmergencyModeView: View {
    @Binding var isActive: Bool
    let contacts: [EmergencyContact]
    @State private var timeRemaining = 5
    @State private var contacting = false
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.9)
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                VStack(spacing: 10) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 60))
                        .foregroundColor(.red)
                    
                    Text("EMERGENCY MODE")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    if timeRemaining > 0 && !contacting {
                        Text("Contacting emergency contacts in \(timeRemaining) seconds")
                            .font(.headline)
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                    } else if contacting {
                        Text("Contacting emergency services...")
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                }
                
                if !contacts.isEmpty {
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Emergency Contacts")
                            .font(.headline)
                            .foregroundColor(.white)
                        
                        ForEach(contacts.prefix(3)) { contact in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(contact.name)
                                        .font(.headline)
                                        .foregroundColor(.white)
                                    
                                    Text(contact.phoneNumber)
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                }
                                
                                Spacer()
                                
                                Image(systemName: contacting ? "phone.circle.fill" : "phone.circle")
                                    .foregroundColor(contacting ? .green : .white)
                                    .font(.title2)
                            }
                            .padding()
                            .background(Color.white.opacity(0.1))
                            .cornerRadius(10)
                        }
                    }
                    .padding()
                    .background(Color.black.opacity(0.5))
                    .cornerRadius(16)
                } else {
                    Text("No emergency contacts found")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(10)
                }
                
                HStack(spacing: 20) {
                    Button(action: {
                        withAnimation {
                            isActive = false
                        }
                    }) {
                        Text("Cancel")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.gray)
                            .cornerRadius(12)
                    }
                    
                    Button(action: {
                        contacting = true
                        timeRemaining = 0
                        contactEmergencyServices()
                    }) {
                        Text("Contact Now")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(12)
                    }
                }
            }
            .padding(24)
        }
        .onAppear {
            UIApplication.shared.isIdleTimerDisabled = true
        }
        .onDisappear {
            UIApplication.shared.isIdleTimerDisabled = false
        }
        .onReceive(timer) { _ in
            if timeRemaining > 0 && !contacting {
                timeRemaining -= 1
                let generator = UIImpactFeedbackGenerator(style: .medium)
                generator.impactOccurred()
            } else if timeRemaining == 0 && !contacting {
                contacting = true
                contactEmergencyServices()
            }
        }
    }
    
    func contactEmergencyServices() {
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            if let firstContact = contacts.first {
                if let url = URL(string: "tel://\(firstContact.phoneNumber.filter { $0.isNumber })") {
                    UIApplication.shared.open(url)
                }
            }
        }
    }
}
