//
//  Property.swift
//  PropertyPulseProject
//
//  Created by shaden Almarri on 11/11/2023.
//

import Foundation

struct Property: Codable, CustomStringConvertible {
    
    let propertyID: String
    let propertyType: String
    let ListingType: String
    let propertySize: String
    let propertyBedroom: Int
    let propertyBathroom: Int
    let propertyLocation: Location
    let propertyPrice: Float
    let phoneNumber: Int

    var description: String {
        "ID: \(propertyID)\n" +
        "Type: \(propertyType)\n" +
        "Listing: \(ListingType)\n" +
        "Size: \(propertySize)\n" +
        "Bedroom: \(propertyBedroom)\n" +
        "Bathroom: \(propertyBathroom)\n" +
        "Price: \(propertyPrice)\n" +
        "Location: \(propertyLocation)\n" +
        "ContactN: \(phoneNumber)\n"
    }
}

struct Location: Codable {
    let area: String
    let street: String
}

