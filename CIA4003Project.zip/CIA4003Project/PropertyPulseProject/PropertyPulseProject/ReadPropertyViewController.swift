//
//  ReadPropertyViewController.swift
//  PropertyPulseProject
//
//  Created by aisha alzaabi on 11/11/2023.
//
import UIKit
import FirebaseFirestore
import FirebaseFirestoreSwift

class ReadPropertyViewController: UIViewController,  UITableViewDelegate, UITableViewDataSource {

    let PropertyCollection = Firestore.firestore().collection("Property")
    let cellReuseIdentifier = "cell"
    var property: [Property] = []
    let sequeIdentifier = "updatedelete"

    
    @IBOutlet var txSearch: UITextField!
    
    @IBOutlet var tblProperty: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblProperty.delegate = self
        tblProperty.dataSource = self
        
        self.getAllData()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return property.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:PropertyTableViewCell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier) as! PropertyTableViewCell
        
        let propertyData = property[indexPath.row]
        cell.lblProperty?.text = "\(propertyData.ListingType)\(propertyData.propertyPrice)"
        
        return cell
    }
    

    func getAllData(){
        PropertyCollection.getDocuments() { (querySnapshot, err) in
            if let err=err {
                print ("ERROR GETTING DOCUMENTS: \(err)")
            }
            else {
                self.property = []
                //var result = ""
                for document in querySnapshot!.documents {
                    do {
                        let propertyData = try document.data(as: Property.self)
                        self.property.append(propertyData)
                        //result += "\(familyData.name) \(familyData.age) (\(familyData.gender))\n"
                    }catch {
                        print("Error retriving document");
                    }
                }
                OperationQueue.main.addOperation {
                    self.tblProperty.reloadData()
                }
            }
        }
        
        func prepare(for seque: UIStoryboardSegue, sender: Any?) {
            if seque.identifier == sequeIdentifier,
               let destination = seque.destination as? UpdateDeleteViewController,
               let indexPath = tblProperty.indexPathForSelectedRow
            {
                tblProperty.deselectRow(at: indexPath, animated: true)
                destination.selectedProperty = property[indexPath.row]
                //destination.source = self
            }
        }


    }
    
    
    @IBAction func searchClick(_ sender: Any) {
        
        let ListingType = txSearch.text!
        PropertyCollection.whereField("name", isEqualTo: ListingType) . getDocuments() { (querySnapshot,err) in
            if let err = err {
                print ("Error getting document: \(err)")
            }
            else {
                //var result = ""
                self.property = []
                for document in querySnapshot!.documents {
                    do {
                        let propertyData = try document.data(as: Property.self)
                        //result += paintingData.description  + "\n"
                        self.property.append(propertyData)
                    }catch {
                        print("Error reading the data")
                    }
                    //self.lblText.text = result
                    self.tblProperty.reloadData()
                }
            }
        }
    }
    
    
    @IBAction func exitClick(_ sender: Any) {
        self.getAllData()
        txSearch.text = ""
    }
    

}
