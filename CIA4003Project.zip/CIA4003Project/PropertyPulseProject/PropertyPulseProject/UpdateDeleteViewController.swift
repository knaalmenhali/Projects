//
//  UpdateDeleteViewController.swift
//  PropertyPulseProject
//
//  Created by shaden Almarri on 11/11/2023.
//

import Foundation
import UIKit
import FirebaseFirestoreSwift
import FirebaseFirestore

class UpdateDeleteViewController: UIViewController {
    
    @IBOutlet var tfID: UITextField!
    @IBOutlet var tfType:UITextField!
    @IBOutlet var tfSize:UITextField!
    @IBOutlet var tfBedroom:UITextField!
    @IBOutlet var tfBathroom:UITextField!
    @IBOutlet var tfArea:UITextField!
    @IBOutlet var tfStreet:UITextField!
    @IBOutlet var tfPrice:UITextField!
    @IBOutlet var tfListing:UITextField!
    @IBOutlet var tfContactN:UITextField!
    @IBOutlet var btnUpdate: UIButton!
    
    
    let propertyCollection = Firestore.firestore().collection("Property")
    var selectedProperty: Property? = nil
       
       override func viewDidLoad() {
     
           super.viewDidLoad()
           tfID.isEnabled = false
           tfType.isEnabled = false
           tfSize.isEnabled = false
           tfBedroom.isEnabled = false
           tfBathroom.isEnabled = false
           tfArea.isEnabled = false
           tfStreet.isEnabled = false
           tfPrice.isEnabled = false
           tfListing.isEnabled = false
           tfContactN.isEnabled = false
           btnUpdate.isEnabled = false
           
           if let Property = selectedProperty {
               tfListing.text = String(Property.ListingType)
               tfType.text = String(Property.propertyType)
           }
           
       }
       
       @IBAction func onUpdateClick(_sender: Any){
           let propertyid = tfID.text!
           propertyCollection.whereField("ID", isEqualTo: propertyid).getDocuments{(querySnapshot,err) in
               if let err = err {
                   print("Error getting documents: \(err)")
               }
               else if let querySnapshot = querySnapshot, !querySnapshot.isEmpty {
                   querySnapshot.documents[0].reference.updateData([ "Type":self.tfType.text!, "Size":self.tfSize.text!,       "ID":propertyid, "Bedroom":Int(self.tfBedroom.text!)!,"Bathroom":Int(self.tfBathroom.text!),"Area":self.tfArea.text!,"Street":self.tfStreet.text!, "price":Float(self.tfPrice.text!),"Listing": self.tfListing.text!, "ContactN": Int(self.tfContactN.text!)!] ){ err in
                       if let err = err {
                           print("Error updating documents: \(err)")
                           
                       }
                       else {
                           print("Property updated successfully")
                           self.performSegue(withIdentifier: "mainpage", sender: self)
                           
                       }
                       
                   }
                   
               }
               else {
                   print("Nothing to update")
                   let dialogMessage = UIAlertController(title: "Attention", message: "Nothing to update.", preferredStyle: .alert)
                   // Present alert to user
                   let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                       print("Ok button tapped")
                       
                   })
                   //Add OK button to a dialog message
                   dialogMessage.addAction(ok)
                   // Present Alert to
                   // self.present(dialogMessage, animated: true, completion: nil)
               }
           }
       }
       
       @IBAction func onDeleteClick(_sender: Any){
           let propertyid = tfID.text!
           propertyCollection.whereField("ID", isEqualTo: propertyid).getDocuments{(querySnapshot,err) in
               if let err = err{
                   print("Error getting documents: \(err)")
               }
               else if let querySnapshot = querySnapshot, !querySnapshot.isEmpty{
                   querySnapshot.documents[0].reference.delete(){
                       err in
                       if let err = err {
                           print("Error deleting documents: \(err)")
                       }
                       else{
                           print("Property delete successfully")
                           //self.dismiss(animated: true)
                           self.performSegue(withIdentifier: "mainpage", sender: self)
                       }
                   }
               }
               else{
                   print("nothing to delete")
               }
           }
           
       }
       
       @IBAction func onCancelClick(_sender: Any){
           tfID.isEnabled = true
           tfType.isEnabled = true
           tfSize.isEnabled = true
           tfBedroom.isEnabled = true
           tfBathroom.isEnabled = true
           tfArea.isEnabled = true
           tfStreet.isEnabled = true
           tfPrice.isEnabled = true
           tfListing.isEnabled = true
           tfContactN.isEnabled = true
           btnUpdate.isEnabled = true
           self.dismiss(animated: true)
           
       }
       
   }
