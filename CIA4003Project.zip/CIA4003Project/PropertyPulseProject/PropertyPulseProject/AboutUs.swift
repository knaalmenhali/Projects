//
//  AboutUs.swift
//  PropertyPulseProject
//
//  Created by aisha alzaabi on 13/11/2023.
//

import Foundation
struct AboutUs: Codable {
    let Rule1: String
    let Rule2: String
    let Rule3: String
    let Rule4: String
}

