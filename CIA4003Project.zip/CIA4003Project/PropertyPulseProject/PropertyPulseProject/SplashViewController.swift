//
//  SplashViewController.swift
//  PropertyPulseProject
//
//  Created by shaden Almarri on 11/11/2023.
//

import Foundation
import UIKit

class SplashViewController:UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
            DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: {self.performSegue(withIdentifier: "LoginVC", sender: self)
            })
        }
    }

