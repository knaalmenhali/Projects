//
//  AddViewController.swift
//  PropertyPulseProject
//
//  Created by shaden Almarri on 11/11/2023.
//

import Foundation
import Firebase
import FirebaseFirestoreSwift
import FirebaseAuth
import MobileCoreServices

class AddViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    @IBOutlet var tfID: UITextField!
    @IBOutlet var tfType:UITextField!
    @IBOutlet var tfSize:UITextField!
    @IBOutlet var tfBedroom:UITextField!
    @IBOutlet var tfBathroom:UITextField!
    @IBOutlet var tfArea:UITextField!
    @IBOutlet var tfStreet:UITextField!
    @IBOutlet var tfPrice:UITextField!
    @IBOutlet var tfListing:UITextField!
    @IBOutlet var tfContactN:UITextField!
    
    let propertyCollection = Firestore.firestore().collection("Property")
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        imgPhoto.image = image
        
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
    }
    
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        
        picker.dismiss(animated: true, completion: nil)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onTakePhotoClick(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
                    let imagePicker = UIImagePickerController()
                    imagePicker.delegate = self
                    imagePicker.sourceType = .camera
                    imagePicker.mediaTypes = [kUTTypeImage as String]
                    imagePicker.allowsEditing = false
                    present(imagePicker, animated: true, completion: nil)
                } else {
                    print("Camera source is not available")
                }
            }
        
    
    @IBAction func onSelectPhotoClick(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            imagePicker.mediaTypes = [kUTTypeImage as String]
            imagePicker.allowsEditing = false
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera source is not available")
        }
     
    }
    
    
    @IBOutlet weak var imgPhoto: UIImageView!
    
    
    func check() -> Bool{
        var result = false
        if tfID.text != "" && tfType.text != "" &&
            tfSize.text != "" && tfBedroom.text != "" &&
            tfBathroom.text != "" && tfArea.text != "" &&
            tfStreet.text != "" && tfPrice.text != "" &&
            tfListing.text != "" && tfContactN.text != ""
        {
            result = true
        }
        else{
            result = false
        }
        return result
    }
    
    
    @IBAction func btnAddProperty(_ sender: Any) {
        if check()
        {
            let propertyID = tfID.text!
            propertyCollection.whereField("ID", isEqualTo:propertyID).getDocuments{
                (querySnapshot, err) in
                if let err=err{
                    print("Error getting documents: \(err)")
                }
                else if let querySnapshot = querySnapshot, querySnapshot.isEmpty{
                    self.propertyCollection.document().setData([
                        "ID": propertyID,
                        "Type": self.tfType.text!,
                        "Listing": self.tfListing.text!,
                        "Size": self.tfSize.text!,
                        "Bedroom": Int(self.tfBedroom.text!)!,
                        "Bathroom": Int(self.tfBathroom.text!)!,
                        "Area": self.tfArea.text!,
                        "Street": self.tfStreet.text!,
                        "Price": Float(self.tfPrice.text!)!,
                        "contactN": Int(self.tfContactN.text!)!,]){err in
                        if let err = err {
                            print("Error getting document: \(err)")
                        }
                        else{
                            self.tfID.text = ""
                            self.tfType.text = ""
                            self.tfSize.text = ""
                            self.tfListing.text = ""
                            self.tfBedroom.text = ""
                            self.tfBathroom.text = ""
                            self.tfArea.text = ""
                            self.tfStreet.text = ""
                            self.tfPrice.text = ""
                            self.tfContactN.text = ""
                            print("Property Successfully added")
                        }
                    }
                }
                else{
                    print("Unable to add the Property:  Property with ID \(propertyID) exists")
                }
            }
        }
        else{
            print(" input cannot be empty ")
        }
        
    }
}

