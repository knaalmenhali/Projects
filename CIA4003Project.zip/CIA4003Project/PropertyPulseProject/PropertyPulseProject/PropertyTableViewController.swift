//
//  PropertyTableViewController.swift
//  PropertyPulseProject
//
//  Created by aisha alzaabi on 11/11/2023.
//

import Foundation
import UIKit
import FirebaseFirestore
import FirebaseFirestoreSwift

class PropertyTableViewController: UITableViewController{
    
    let collection = Firestore.firestore().collection("Property")
    let celReuseIdentifier = "cell"
    var property: [String] = []
        //var paintaing: [Painting] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        readAllProperty()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return property.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:PropertyTableViewCell = tableView.dequeueReusableCell(withIdentifier: celReuseIdentifier) as! PropertyTableViewCell
        
        return cell
    }
    
    
    //method to run when table view cell is tapped
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("You tapped cell number \(indexPath.row).")
    }
    func readAllProperty() {

    }
}
