//
//  PropertyTableViewCell.swift
//  PropertyPulseProject
//
//  Created by aisha alzaabi on 11/11/2023.
//

import UIKit

class PropertyTableViewCell: UITableViewCell{
    @IBOutlet var lblProperty: UILabel!
    
}
