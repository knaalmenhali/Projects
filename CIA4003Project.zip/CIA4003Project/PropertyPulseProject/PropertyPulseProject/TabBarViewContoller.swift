//
//  TabBarViewContoller.swift
//  PropertyPulseProject
//
//  Created by shaden Almarri on 11/11/2023.
//

import Foundation
import UIKit

class TabBarViewContoller: UIViewController{
    
  override func viewDidLoad() {
        
        let backButton = UIBarButtonItem()
        backButton.title = "Log Out"
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
    }
}
