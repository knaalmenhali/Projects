//
//  AboutUsViewController.swift
//  PropertyPulseProject
//
//  Created by aisha alzaabi on 13/11/2023.
//

import Foundation
import UIKit

class AboutUsViewController: UIViewController{
    
    var pt = AboutUs(Rule1: "", Rule2: "", Rule3:"", Rule4: "")
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
@IBOutlet weak var lbl_AboutUs: UILabel!
    
    
@IBAction func onJSONDataClick(_ sender: UIButton) {

        let urlString = "https://api.jsonserve.com/kb9EgF"
        let url = URL(string:urlString)!
        
        //create a network request
        //network request runs in background queue
        
        let task = URLSession.shared.dataTask(with: url){
            (data, response, error) in
            if error != nil{
                print("error getting accessing the server")
            }
            else{
                do{
                    let decoder = JSONDecoder()
                    let result = try decoder.decode(AboutUs.self, from:data!)
                    self.pt = result
                    OperationQueue.main.addOperation {
                        [self] in var msg = "Rule1:\(self.pt.Rule1)\n Rule2: \(self.pt.Rule2)\n Rule3: \(self.pt.Rule3) \n Rule4: \(self.pt.Rule4) \n"
                        lbl_AboutUs.text = msg
                    }
                }
                catch{
                    print("Invalid Jason Data")
                }
            }
        }
        task.resume()
          }
    
}
