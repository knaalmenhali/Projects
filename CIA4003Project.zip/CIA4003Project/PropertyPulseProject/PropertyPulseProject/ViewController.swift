//
//  ViewController.swift
//  PropertyPulseProject
//
//  Created by shaden Almarri on 11/11/2023.
//

import UIKit
import FirebaseFirestore
import FirebaseFirestoreSwift
import FirebaseAuth


class ViewController: UIViewController {

    
    
    @IBOutlet var tfEmail:UITextField!
    @IBOutlet var tfPassword:UITextField!
    
    override func viewDidLoad() {
        // Do any additional setup after loading the view.
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated: false)
    }
    
    
    func printError(_ msg: String){
        print(msg)
        dismiss(animated: true)
    }
    
    
    @IBAction func onLoginClick(_ sender: Any){
        if tfEmail.text!.isEmpty || tfPassword.text!.isEmpty{
                    printError("Failure in signing in user: Email or Password is empty....")
                }
                else{
                    Auth.auth().signIn(withEmail: tfEmail.text!, password: tfPassword.text!){
                        (result, err) in
                        if let err = err {
                            self.printError("Failure in signing in user: \(err.localizedDescription)")
                        }
                        else{
                            print("User signed in successfully")
                            self.dismiss(animated: true)
                        }
                    }
                }
    }
    
    @IBAction func onRegisterClick(_ sender: Any){
        if tfEmail.text!.isEmpty || tfPassword.text!.isEmpty {
            printError("failure is creating new user: Email or Password is empty... ")
        }
        
        else {
            Auth.auth().createUser(withEmail: tfEmail.text!, password: tfPassword.text!) { (Result,err) in
                if let err = err {
                    self.printError("failure in creating new user: \(err.localizedDescription)")
                    print("failure in creating new user:")
                    let dialogMessage = UIAlertController(title: "Attention", message: "Nothing to login.", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                        print("OK button tapped")
                    })
                    dialogMessage.addAction(ok)
                    self.present(dialogMessage, animated: true, completion: nil)
                }
                
                
                else{
                    print("new user created sucsasfully")
                    self.dismiss(animated: true)
                    
                }
            }
        }
    }
    
}

