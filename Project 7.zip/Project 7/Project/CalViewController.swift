//
//  CalViewController.swift
//  Project
//
//  Created by Kanna  on 18/03/2024.
//

import UIKit

class CalViewController: UIViewController {
    @IBOutlet weak var calorieInput: UITextField!
    @IBOutlet weak var totalCalories: UILabel!
    
    @IBOutlet var DCal: UITextField!
    @IBOutlet var LCal: UITextField!
    var totalCaloriesCount: Int = 0
    
    @IBAction func addButtonTapped(_ sender: UIButton) {
            if let input = calorieInput.text, let DCalCount = Int(DCal.text ?? "0"), let LCalCount = Int(LCal.text ?? "0"), let calorieCount = Int(input) {
                totalCaloriesCount += calorieCount + DCalCount + LCalCount
                totalCalories.text = "\(totalCaloriesCount)"
            }
        }
    }
