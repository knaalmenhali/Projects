import UIKit

class MealTableViewController: UITableViewController {
    var meals = [Meal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Load sample data
        loadSampleMeals()
        
        // Add an Edit button to the navigation bar
        navigationItem.rightBarButtonItem = editButtonItem
    }
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return meals.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "MealTableViewCell"
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? MealTableViewCell else {
            fatalError("The dequeued cell is not an instance of MealTableViewCell.")
        }
        
        let meal = meals[indexPath.row]
        
        cell.nameLabel.text = meal.mealName
        cell.caloriesLabel.text = "Calories: \(meal.calories)"
        cell.fatLabel.text = "Fat: \(meal.fat)"
        cell.photoImageView.image = meal.photo
        
        return cell
    }
    
    // MARK: - Table view delegate
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            meals.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowDetail" {
            if let mealViewController = segue.destination as? MealViewController {
                if let selectedMeal = sender as? Meal {
                    mealViewController.meal = selectedMeal
                }
            }
        }
    }
    
    // MARK: - Private methods
    
    private func loadSampleMeals() {
        let meal1 = Meal(mealName: "Caprese Salad", mealDescription: "Fresh tomatoes, mozzarella, basil, and balsamic glaze", calories: 150, fat: 6.0, protein: 12.0, photo: UIImage(named: "meal1"))
        
        let meal2 = Meal(mealName: "Chicken and Potatoes", mealDescription: "Roasted chicken with seasoned potatoes", calories: 400, fat: 12.0, protein: 20.0, photo: UIImage(named: "meal2"))
        
        let meal3 = Meal(mealName: "Pasta with Meatballs", mealDescription: "Spaghetti with homemade meatballs", calories: 350, fat: 10.0, protein: 35.0, photo: UIImage(named: "meal3"))

        meals += [meal1, meal2, meal3]
    }
    
    // MARK: - Table view delegate
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let selectedMeal = meals[indexPath.row]
        performSegue(withIdentifier: "ShowDetail", sender: selectedMeal)
    }
    
    // MARK: - Unwind Segue
    
    @IBAction func unwindToMealList(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.source as? MealViewController {
            if let meal = sourceViewController.meal {
                meals.append(meal) // Append meal to the meals array
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }
    }
}
