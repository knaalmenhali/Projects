//
//  MEALS.swift
//  Project
//
//  Created by Fatima Lari on 23/03/2024.
//

import UIKit

class Meal {
    var mealName: String
    var mealDescription: String
    var calories: Int
    var fat: Double
    var protein: Double
    var photo: UIImage?
    
    init(mealName: String, mealDescription: String, calories: Int, fat: Double, protein: Double, photo: UIImage?) {
        self.mealName = mealName
        self.mealDescription = mealDescription
        self.calories = calories
        self.fat = fat
        self.protein = protein
        self.photo = photo
    }
}
