-- Drop foreign key constraints
ALTER TABLE driver DROP CONSTRAINT driver_license_fk;
ALTER TABLE booking DROP CONSTRAINT booking_trip_fk;
ALTER TABLE bus DROP CONSTRAINT bus_vehicle_fk;
ALTER TABLE car DROP CONSTRAINT car_vehicle_fk;
ALTER TABLE passenger DROP CONSTRAINT passenger_vehicle_fk;
ALTER TABLE passenger_booking DROP CONSTRAINT booking_fk;
ALTER TABLE passenger_booking DROP CONSTRAINT passenger_fk;
ALTER TABLE trip DROP CONSTRAINT trip_vehicle_fk;
ALTER TABLE vehicle DROP CONSTRAINT vehicle_driver_fk;
ALTER TABLE vehicle DROP CONSTRAINT vehicle_route_fk;

-- Drop CHECK constraints
ALTER TABLE vehicle DROP CONSTRAINT Vehicle_Check_Capacity;
ALTER TABLE bus DROP CONSTRAINT Bus_Check_TimeOrder;
ALTER TABLE car DROP CONSTRAINT Car_Check_TransmissionType;
ALTER TABLE car DROP CONSTRAINT Car_Check_FuelType;
ALTER TABLE driver_license DROP CONSTRAINT DriverLicense_Check_IssueDate_ExpiryDate;
ALTER TABLE vehicle DROP CONSTRAINT Vehicle_Type_Check;
ALTER TABLE booking DROP CONSTRAINT Booking_Check_Status;

-- Drop UNIQUE constraints
ALTER TABLE vehicle DROP CONSTRAINT Vehicle_Unique_PlateNumber;
ALTER TABLE driver DROP CONSTRAINT Driver_Unique_PhoneNumber;
ALTER TABLE driver DROP CONSTRAINT Driver_Unique_Email;
ALTER TABLE passenger DROP CONSTRAINT Passenger_Unique_PhoneNumber;
ALTER TABLE passenger DROP CONSTRAINT Passenger_Unique_Email;

-- Drop primary key constraints
ALTER TABLE booking DROP CONSTRAINT booking_pk;
ALTER TABLE driver DROP CONSTRAINT driver_pk;
ALTER TABLE driver_license DROP CONSTRAINT driver_license_pk;
ALTER TABLE passenger DROP CONSTRAINT passenger_pk;
ALTER TABLE route DROP CONSTRAINT route_pk;
ALTER TABLE trip DROP CONSTRAINT trip_pk;
ALTER TABLE vehicle DROP CONSTRAINT vehicle_pk;

-- Drop sequences
DROP SEQUENCE booking_pk_seq;
DROP SEQUENCE driver_pk_seq;
DROP SEQUENCE driver_license_pk_seq;
DROP SEQUENCE passenger_pk_seq;
DROP SEQUENCE route_pk_seq;
DROP SEQUENCE trip_pk_seq;
DROP SEQUENCE vehicle_pk_seq;

-- Drop tables (if they exist)
DROP TABLE passenger_booking;
DROP TABLE booking;
DROP TABLE bus;
DROP TABLE car;
DROP TABLE driver_license;
DROP TABLE passenger;
DROP TABLE route;
DROP TABLE trip;
DROP TABLE vehicle;
DROP TABLE driver;

-- Create tables

CREATE TABLE route (
    routeid       NUMBER(10) NOT NULL,
    routename     VARCHAR2(20) NOT NULL,
    startlocation VARCHAR2(30) NOT NULL,
    endlocation   VARCHAR2(30) NOT NULL
);

CREATE TABLE driver (
    driverid                     NUMBER(10) NOT NULL,
    drivername                   VARCHAR2(20) NOT NULL,
    phonenumber                  VARCHAR2(10) NOT NULL,
    email                        VARCHAR2(30) NOT NULL,
    driver_license_licensenumber NUMBER(10) NOT NULL
);

CREATE TABLE driver_license (
    licensenumber     NUMBER(10) NOT NULL,
    fullname          VARCHAR2(20) NOT NULL,
    dob               DATE NOT NULL,
    nationality       VARCHAR2(10) NOT NULL,
    issuedate         DATE NOT NULL,
    expirydate        DATE NOT NULL

);

CREATE TABLE vehicle (
    vehicleid       NUMBER(10) NOT NULL,
    vehiclename     VARCHAR2(30) NOT NULL,
    capacity        INTEGER NOT NULL,
    vehiclemodel    VARCHAR2(30) NOT NULL,
    platenumber     INTEGER NOT NULL,
    driver_driverid NUMBER(10) NOT NULL,
    route_routeid   NUMBER(10) NOT NULL,
    vehicleType     VARCHAR2(10) NOT NULL
);

CREATE TABLE booking (
    bookingid        NUMBER(10) NOT NULL,
    BookingDate      DATE NOT NULL,
    status           VARCHAR2(10) NOT NULL,
    trip_tripid       NUMBER(10) NOT NULL
);


CREATE TABLE trip (
    tripid            NUMBER(10) NOT NULL,
    trip_date         DATE NOT NULL,
    time              DATE NOT NULL,
    price             NUMBER NOT NULL,
    vehicle_vehicleid NUMBER(10) NOT NULL

);

CREATE TABLE passenger (
    passengerid         NUMBER(10) NOT NULL,
    passengername       VARCHAR2(20) NOT NULL,
    phonenumber         VARCHAR2(10) NOT NULL,
    email               VARCHAR2(30) NOT NULL,
    paymentinfo         VARCHAR2(20) NOT NULL,
    vehicle_vehicleid   NUMBER(10) NOT NULL
);


CREATE TABLE bus (
    vehicleid      NUMBER(10) NOT NULL,
    departuretime  DATE NOT NULL,
    arrivaltime    DATE NOT NULL
);

CREATE TABLE car (
    vehicleid        NUMBER(10) NOT NULL,
    transmissiontype VARCHAR2(10) NOT NULL,
    fueltype         VARCHAR2(10) NOT NULL
);

CREATE TABLE passenger_booking (
    passenger_passengerid NUMBER(10) NOT NULL,
    booking_bookingid     NUMBER(10) NOT NULL
);


-- Add primary key constraints
ALTER TABLE booking
    ADD CONSTRAINT booking_pk PRIMARY KEY (bookingid);

ALTER TABLE driver
    ADD CONSTRAINT driver_pk PRIMARY KEY (driverid);

ALTER TABLE driver_license
    ADD CONSTRAINT driver_license_pk PRIMARY KEY (licensenumber);

ALTER TABLE passenger
    ADD CONSTRAINT passenger_pk PRIMARY KEY (passengerid);

ALTER TABLE passenger_booking
    ADD CONSTRAINT relation_10_pk PRIMARY KEY (passenger_passengerid, booking_bookingid);

ALTER TABLE route
    ADD CONSTRAINT route_pk PRIMARY KEY (routeid);

ALTER TABLE trip
    ADD CONSTRAINT trip_pk PRIMARY KEY (tripid);

ALTER TABLE vehicle
    ADD CONSTRAINT vehicle_pk PRIMARY KEY (vehicleid);

-- Add foreign key constraints

ALTER TABLE booking
    ADD CONSTRAINT booking_trip_fk FOREIGN KEY (trip_tripid)
        REFERENCES trip (tripid);


ALTER TABLE bus
    ADD CONSTRAINT bus_vehicle_fk FOREIGN KEY (vehicleid)
        REFERENCES vehicle (vehicleid);

ALTER TABLE car
    ADD CONSTRAINT car_vehicle_fk FOREIGN KEY (vehicleid)
        REFERENCES vehicle (vehicleid);

ALTER TABLE passenger
    ADD CONSTRAINT passenger_vehicle_fk FOREIGN KEY (vehicle_vehicleid)
        REFERENCES vehicle (vehicleid);

ALTER TABLE passenger_booking
    ADD CONSTRAINT booking_fk FOREIGN KEY (booking_bookingid)
        REFERENCES booking (bookingid);

ALTER TABLE passenger_booking
    ADD CONSTRAINT passenger_fk FOREIGN KEY (passenger_passengerid)
        REFERENCES passenger (passengerid);

ALTER TABLE trip
    ADD CONSTRAINT trip_vehicle_fk FOREIGN KEY (vehicle_vehicleid)
        REFERENCES vehicle (vehicleid);

ALTER TABLE vehicle
    ADD CONSTRAINT vehicle_driver_fk FOREIGN KEY (driver_driverid)
        REFERENCES driver (driverid);

ALTER TABLE vehicle
    ADD CONSTRAINT vehicle_route_fk FOREIGN KEY (route_routeid)
        REFERENCES route (routeid);

ALTER TABLE driver
    ADD CONSTRAINT driver_license_fk FOREIGN KEY (driver_license_licensenumber)
    REFERENCES driver_license (licensenumber);



-- Add CHECK constraints and unique constraints
ALTER TABLE booking
    ADD CONSTRAINT Booking_Check_Status CHECK (status IN ('Reserved', 'Confirmed', 'Cancelled'));

ALTER TABLE bus
    ADD CONSTRAINT Bus_Check_TimeOrder CHECK (departuretime < arrivaltime);

ALTER TABLE car
    ADD CONSTRAINT Car_Check_TransmissionType CHECK (transmissiontype IN ('Automatic', 'Manual'));

ALTER TABLE car
    ADD CONSTRAINT Car_Check_FuelType CHECK (fueltype IN ('Gasoline', 'Diesel', 'Electric'));

ALTER TABLE driver_license
    ADD CONSTRAINT DriverLicense_Check_IssueDate_ExpiryDate CHECK (issuedate < expirydate);

ALTER TABLE vehicle 
     ADD CONSTRAINT Vehicle_Type_Check CHECK (vehicleType IN ('car', 'bus'));


ALTER TABLE vehicle
    ADD CONSTRAINT Vehicle_Check_Capacity CHECK (capacity > 0);



-- Add unique constraints
ALTER TABLE vehicle
    ADD CONSTRAINT Vehicle_Unique_PlateNumber UNIQUE (platenumber);

ALTER TABLE driver
    ADD CONSTRAINT Driver_Unique_PhoneNumber UNIQUE (phonenumber);

ALTER TABLE driver
    ADD CONSTRAINT Driver_Unique_Email UNIQUE (email);

ALTER TABLE passenger
    ADD CONSTRAINT Passenger_Unique_PhoneNumber UNIQUE (phonenumber);

ALTER TABLE passenger
    ADD CONSTRAINT Passenger_Unique_Email UNIQUE (email);


-- Create sequences for primary keys
CREATE SEQUENCE booking_pk_seq
  START WITH 1
  INCREMENT BY 1;

CREATE SEQUENCE driver_pk_seq
  START WITH 1
  INCREMENT BY 1;

CREATE SEQUENCE driver_license_pk_seq
  START WITH 1
  INCREMENT BY 1;

CREATE SEQUENCE passenger_pk_seq
  START WITH 1
  INCREMENT BY 1;


CREATE SEQUENCE route_pk_seq
  START WITH 1
  INCREMENT BY 1;

CREATE SEQUENCE trip_pk_seq
  START WITH 1
  INCREMENT BY 1;

CREATE SEQUENCE vehicle_pk_seq
  START WITH 1
  INCREMENT BY 1;


 -- route table

INSERT INTO route (routeid, routename, startlocation, endlocation)
VALUES (route_pk_seq.NEXTVAL, 'Route 1', 'Alshamkah', 'baniyas');

INSERT INTO route (routeid, routename, startlocation, endlocation)
VALUES (route_pk_seq.NEXTVAL, 'Route 2', 'Abu Dhabi', 'Dubai');

INSERT INTO route (routeid, routename, startlocation, endlocation)
VALUES (route_pk_seq.NEXTVAL, 'Route 3', 'Dubai', 'RAK');

INSERT INTO route (routeid, routename, startlocation, endlocation)
VALUES (route_pk_seq.NEXTVAL, 'Route 4', 'mohammed bin zayed', ' baniyas');

INSERT INTO route (routeid, routename, startlocation, endlocation)
VALUES (route_pk_seq.NEXTVAL, 'Route 5', 'khalifa city', 'dubai');

INSERT INTO route (routeid, routename, startlocation, endlocation)
VALUES (route_pk_seq.NEXTVAL, 'Route 6', 'RAK', 'dubai');

INSERT INTO route (routeid, routename, startlocation, endlocation)
VALUES (route_pk_seq.NEXTVAL, 'Route 7', 'highr colleage of technology', 'baniyas');

INSERT INTO route (routeid, routename, startlocation, endlocation)
VALUES (route_pk_seq.NEXTVAL, 'Route 8', 'Al Ain', 'dubai');

INSERT INTO route (routeid, routename, startlocation, endlocation)
VALUES (route_pk_seq.NEXTVAL, 'Route 9', 'Shkaboot', 'baniyas east');

INSERT INTO route (routeid, routename, startlocation, endlocation)
VALUES (route_pk_seq.NEXTVAL, 'Route 10', 'khalifa city', 'highr colleage of technology');

-- driver license table

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'John Smith', TO_DATE('1980-01-15', 'YYYY-MM-DD'), 'US', TO_DATE('2022-01-15', 'YYYY-MM-DD'), TO_DATE('2025-01-15', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Jane Smith', TO_DATE('1985-03-20', 'YYYY-MM-DD'), 'CA', TO_DATE('2021-05-10', 'YYYY-MM-DD'), TO_DATE('2024-05-10', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Alice Johnson', TO_DATE('1977-11-28', 'YYYY-MM-DD'), 'US', TO_DATE('2019-07-12', 'YYYY-MM-DD'), TO_DATE('2023-07-12', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Bob Wilson', TO_DATE('1990-04-05', 'YYYY-MM-DD'), 'CA', TO_DATE('2020-12-10', 'YYYY-MM-DD'), TO_DATE('2023-12-10', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Michael Brown', TO_DATE('1982-08-12', 'YYYY-MM-DD'), 'US', TO_DATE('2018-06-25', 'YYYY-MM-DD'), TO_DATE('2022-06-25', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Sarah Johnson', TO_DATE('1990-05-23', 'YYYY-MM-DD'), 'US', TO_DATE('2020-04-10', 'YYYY-MM-DD'), TO_DATE('2025-04-10', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'David Lee', TO_DATE('1985-11-15', 'YYYY-MM-DD'), 'CA', TO_DATE('2019-09-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Emily Davis', TO_DATE('1995-07-30', 'YYYY-MM-DD'), 'GB', TO_DATE('2021-02-15', 'YYYY-MM-DD'), TO_DATE('2026-02-15', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'John Miller', TO_DATE('1978-03-12', 'YYYY-MM-DD'), 'AU', TO_DATE('2017-08-20', 'YYYY-MM-DD'), TO_DATE('2021-08-20', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Anna Wilson', TO_DATE('1992-09-09', 'YYYY-MM-DD'), 'NZ', TO_DATE('2021-01-07', 'YYYY-MM-DD'), TO_DATE('2026-01-07', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'James Taylor', TO_DATE('1988-02-17', 'YYYY-MM-DD'), 'US', TO_DATE('2020-11-12', 'YYYY-MM-DD'), TO_DATE('2024-11-12', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Laura White', TO_DATE('1983-10-01', 'YYYY-MM-DD'), 'CA', TO_DATE('2018-05-05', 'YYYY-MM-DD'), TO_DATE('2023-05-05', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Robert Walker', TO_DATE('1991-06-28', 'YYYY-MM-DD'), 'US', TO_DATE('2022-09-30', 'YYYY-MM-DD'), TO_DATE('2027-09-30', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Samantha Clark', TO_DATE('1993-04-10', 'YYYY-MM-DD'), 'GB', TO_DATE('2020-08-20', 'YYYY-MM-DD'), TO_DATE('2025-08-20', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Daniel Lewis', TO_DATE('1987-12-21', 'YYYY-MM-DD'), 'AU', TO_DATE('2019-03-15', 'YYYY-MM-DD'), TO_DATE('2024-03-15', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Olivia Hall', TO_DATE('1996-01-19', 'YYYY-MM-DD'), 'NZ', TO_DATE('2021-06-01', 'YYYY-MM-DD'), TO_DATE('2026-06-01', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Charles Scott', TO_DATE('1989-11-02', 'YYYY-MM-DD'), 'US', TO_DATE('2020-12-05', 'YYYY-MM-DD'), TO_DATE('2025-12-05', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Emma Young', TO_DATE('1994-08-15', 'YYYY-MM-DD'), 'CA', TO_DATE('2019-04-27', 'YYYY-MM-DD'), TO_DATE('2024-04-27', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'William Harris', TO_DATE('1990-02-05', 'YYYY-MM-DD'), 'GB', TO_DATE('2022-11-18', 'YYYY-MM-DD'), TO_DATE('2027-11-18', 'YYYY-MM-DD'));

INSERT INTO driver_license (licensenumber, fullname, dob, nationality, issuedate, expirydate)
VALUES (driver_license_pk_seq.NEXTVAL, 'Sophia King', TO_DATE('1997-03-23', 'YYYY-MM-DD'), 'US', TO_DATE('2021-08-10', 'YYYY-MM-DD'), TO_DATE('2026-08-10', 'YYYY-MM-DD'));


--driver table 

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'John Smith', '0547263548', 'john.smith@email.com', 1);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Jane Doe', '0527162534', 'jane.doe@email.com', 2);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Robert Johnson', '0545367827', 'robert.johnson@email.com', 3);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Susan White', '0534276539', 'susan.white@email.com', 4);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Michael Brown', '0526384679', 'michael.brown@email.com', 5);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Sarah Johnson', '0526398745', 'sarah.johnson@email.com', 6);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'David Lee', '0527358493', 'david.lee@email.com', 7);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Emily Davis', '0528392019', 'emily.davis@email.com', 8);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'John Miller', '0523489201', 'john.miller@email.com', 9);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Anna Wilson', '0529874530', 'anna.wilson@email.com', 10);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'James Taylor', '0521236745', 'james.taylor@email.com', 11);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Laura White', '0526748392', 'laura.white@email.com', 12);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Robert Walker', '0528745302', 'robert.walker@email.com', 13);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Samantha Clark', '0526358491', 'samantha.clark@email.com', 14);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Daniel Lewis', '0528730209', 'daniel.lewis@email.com', 15);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Olivia Hall', '0520938745', 'olivia.hall@email.com', 16);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Charles Scott', '0523487592', 'charles.scott@email.com', 17);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Emma Young', '0528739230', 'emma.young@email.com', 18);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'William Harris', '0520934837', 'william.harris@email.com', 19);

INSERT INTO driver (driverid, drivername, phonenumber, email, driver_license_licensenumber)
VALUES (driver_pk_seq.NEXTVAL, 'Sophia King', '0527398456', 'sophia.king@email.com', 20);


-- vehicle table 

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Mercedes', 10, 'Mercedes-Benz Sprinte', 12345, 1, 1, 'bus');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Volvo', 9, 'Volvo 9700', 54321, 2, 2, 'bus');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Yutong', 4, 'Yutong TC9', 67890, 3 , 3, 'bus');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'utong', 3, 'utong TC9', 98765, 4, 4, 'bus');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Scania', 3, 'Scania Touring', 24680, 5, 5, 'bus');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Toyota', 3, 'Camry', 13579, 6, 6, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Nissan', 4, 'Altima', 98712, 7, 7, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Honda', 1, 'Accord', 65432, 8, 8, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Mercedes', 2, 'Mercedes-Benz E-Class', 32123, 9, 9, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Ford', 3, 'Explorer', 99765, 10, 10, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Toyota', 4, 'Camry', 56342, 11, 1, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Chevrolet', 5, 'Tahoe', 12987, 12, 2, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Honda', 3, 'Civic', 98723, 13, 3, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Ford', 6, 'Transit', 43211, 14, 4, 'bus');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Mercedes', 2, 'Sprinter', 87321, 15, 5, 'bus');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Lexus', 4, 'RX350', 24980, 16, 6, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'BMW', 4, 'X5', 65328, 17, 7, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Jeep', 5, 'Wrangler', 87592, 18, 8, 'car');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Audi', 20, 'Q7', 43278, 19, 9, 'bus');

INSERT INTO vehicle (vehicleid, vehiclename, capacity, vehiclemodel, platenumber, driver_driverid, route_routeid, vehicleType)
VALUES (vehicle_pk_seq.NEXTVAL, 'Ford', 50, 'F550', 98724, 20, 10, 'bus');


-- trip

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-01', 'YYYY-MM-DD'), TO_DATE('08:00:00', 'HH24:MI:SS'), 100.00, 1);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-05', 'YYYY-MM-DD'), TO_DATE('10:00:00', 'HH24:MI:SS'), 120.00, 2);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-10', 'YYYY-MM-DD'), TO_DATE('12:00:00', 'HH24:MI:SS'), 150.00, 3);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-15', 'YYYY-MM-DD'), TO_DATE('14:00:00', 'HH24:MI:SS'), 130.00, 4);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-20', 'YYYY-MM-DD'), TO_DATE('16:00:00', 'HH24:MI:SS'), 110.00, 5);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-21', 'YYYY-MM-DD'), TO_DATE('09:00:00', 'HH24:MI:SS'), 120.00, 6);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-22', 'YYYY-MM-DD'), TO_DATE('14:30:00', 'HH24:MI:SS'), 95.00, 7);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-23', 'YYYY-MM-DD'), TO_DATE('18:00:00', 'HH24:MI:SS'), 130.00, 8);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-24', 'YYYY-MM-DD'), TO_DATE('07:45:00', 'HH24:MI:SS'), 150.00, 9);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-25', 'YYYY-MM-DD'), TO_DATE('10:00:00', 'HH24:MI:SS'), 100.00, 10);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-26', 'YYYY-MM-DD'), TO_DATE('15:15:00', 'HH24:MI:SS'), 110.00, 11);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-27', 'YYYY-MM-DD'), TO_DATE('12:30:00', 'HH24:MI:SS'), 140.00, 12);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-28', 'YYYY-MM-DD'), TO_DATE('20:00:00', 'HH24:MI:SS'), 160.00, 13);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-29', 'YYYY-MM-DD'), TO_DATE('13:30:00', 'HH24:MI:SS'), 115.00, 14);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-11-30', 'YYYY-MM-DD'), TO_DATE('08:00:00', 'HH24:MI:SS'), 125.00, 15);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-12-01', 'YYYY-MM-DD'), TO_DATE('11:00:00', 'HH24:MI:SS'), 135.00, 16);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-12-02', 'YYYY-MM-DD'), TO_DATE('17:00:00', 'HH24:MI:SS'), 145.00, 17);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-12-03', 'YYYY-MM-DD'), TO_DATE('19:45:00', 'HH24:MI:SS'), 155.00, 18);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-12-04', 'YYYY-MM-DD'), TO_DATE('09:30:00', 'HH24:MI:SS'), 165.00, 19);

INSERT INTO trip (tripid, trip_date, time, price, vehicle_vehicleid)
VALUES (trip_pk_seq.NEXTVAL, TO_DATE('2023-12-05', 'YYYY-MM-DD'), TO_DATE('16:30:00', 'HH24:MI:SS'), 175.00, 20);

-- Insert ten records into the booking table with generated primary keys

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-10-31', 'YYYY-MM-DD'), 'Reserved', 1);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-11-05', 'YYYY-MM-DD'), 'Confirmed', 3);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-11-10', 'YYYY-MM-DD'), 'Cancelled', 4);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-11-15', 'YYYY-MM-DD'), 'Reserved', 1);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-11-20', 'YYYY-MM-DD'), 'Confirmed', 5);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-11-25', 'YYYY-MM-DD'), 'Cancelled', 1);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-11-30', 'YYYY-MM-DD'), 'Reserved', 2);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-05', 'YYYY-MM-DD'), 'Confirmed', 4);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-10', 'YYYY-MM-DD'), 'Cancelled', 5);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-15', 'YYYY-MM-DD'), 'Reserved', 2);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-16', 'YYYY-MM-DD'), 'Confirmed', 3);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-17', 'YYYY-MM-DD'), 'Cancelled', 4);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-18', 'YYYY-MM-DD'), 'Cancelled', 5);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-19', 'YYYY-MM-DD'), 'Confirmed', 6);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-20', 'YYYY-MM-DD'), 'Cancelled', 7);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-21', 'YYYY-MM-DD'), 'Confirmed', 8);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-22', 'YYYY-MM-DD'), 'Reserved', 9);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-23', 'YYYY-MM-DD'), 'Confirmed', 10);

INSERT INTO booking (bookingid, BookingDate, status, trip_tripid)
VALUES (booking_pk_seq.NEXTVAL, TO_DATE('2023-12-24', 'YYYY-MM-DD'), 'Reserved', 11);

--passengers table

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'John Doe', '1234567890', 'johndoe@email.com', 'credit card', 1);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Jane Smith', '9876543210', 'janesmith@email.com', 'apple pay', 2);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Alice Johnson', '5551234567', 'alice@email.com', 'credit card', 3);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Bob Wilson', '9998887777', 'bob@email.com', 'apple pay', 4);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Eve Davis', '1112223333', 'eve@email.com', 'cash', 5);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Charlie Brown', '4445556666', 'charlie@email.com', 'cash', 6);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Grace Miller', '7778889999', 'grace@email.com', 'credit card', 7);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'David Lee', '3332221111', 'david@email.com', 'apple pay', 8);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Olivia Turner', '6665554444', 'olivia@email.com', 'credit card', 9);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Samuel White', '8889990000', 'samuel@email.com', 'cash', 10);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Liam Smith', '8881234567', 'liam.smith@email.com', 'credit', 1);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Olivia Johnson', '8887654321', 'olivia.johnson@email.com', 'debit', 2);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Noah Williams', '8889876543', 'noah.williams@email.com', 'cash', 3);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Emma Brown', '8886543210', 'emma.brown@email.com', 'credit', 4);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Ava Jones', '8883210987', 'ava.jones@email.com', 'debit', 5);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'William Garcia', '8884321098', 'william.garcia@email.com', 'cash', 6);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Sophia Martinez', '8885432109', 'sophia.martinez@email.com', 'credit', 7);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'James Rodriguez', '8886543211', 'james.rodriguez@email.com', 'debit', 8);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Isabella Hernandez', '8887654322', 'isabella.hernandez@email.com', 'cash', 9);

INSERT INTO passenger (passengerid, passengername, phonenumber, email, paymentinfo, vehicle_vehicleid)
VALUES (passenger_pk_seq.NEXTVAL, 'Benjamin Lee', '8888765432', 'benjamin.lee@email.com', 'credit', 10);

--bus table 
-- Inserting bus details into the bus table
INSERT INTO bus (vehicleid, departuretime, arrivaltime)
VALUES (1, TO_DATE('2023-11-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2023-11-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO bus (vehicleid, departuretime, arrivaltime)
VALUES (2, TO_DATE('2023-11-02 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2023-11-02 13:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO bus (vehicleid, departuretime, arrivaltime)
VALUES (3, TO_DATE('2023-11-03 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2023-11-03 14:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO bus (vehicleid, departuretime, arrivaltime)
VALUES (4, TO_DATE('2023-11-04 11:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2023-11-04 15:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO bus (vehicleid, departuretime, arrivaltime)
VALUES (5, TO_DATE('2023-11-05 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2023-11-05 16:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO bus (vehicleid, departuretime, arrivaltime)
VALUES (14, TO_DATE('2023-11-06 13:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2023-11-06 17:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO bus (vehicleid, departuretime, arrivaltime)
VALUES (15, TO_DATE('2023-11-07 14:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2023-11-07 18:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO bus (vehicleid, departuretime, arrivaltime)
VALUES (20, TO_DATE('2023-11-08 15:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2023-11-08 19:00:00', 'YYYY-MM-DD HH24:MI:SS'));

-- car table
INSERT INTO car (vehicleid, transmissiontype, fueltype)
VALUES (6, 'Automatic', 'Gasoline');

INSERT INTO car (vehicleid, transmissiontype, fueltype)
VALUES (7, 'Automatic', 'Gasoline');

INSERT INTO car (vehicleid, transmissiontype, fueltype)
VALUES (8, 'Manual', 'Diesel');

INSERT INTO car (vehicleid, transmissiontype, fueltype)
VALUES (9, 'Automatic', 'Gasoline');

INSERT INTO car (vehicleid, transmissiontype, fueltype)
VALUES (10, 'Manual', 'Diesel');

INSERT INTO car (vehicleid, transmissiontype, fueltype)
VALUES (11, 'Automatic', 'Gasoline');

INSERT INTO car (vehicleid, transmissiontype, fueltype)
VALUES (12, 'Automatic', 'Gasoline');

INSERT INTO car (vehicleid, transmissiontype, fueltype)
VALUES (13, 'Manual', 'Diesel');

INSERT INTO car (vehicleid, transmissiontype, fueltype)
VALUES (14, 'Automatic', 'Gasoline');

INSERT INTO car (vehicleid, transmissiontype, fueltype)
VALUES (15, 'Automatic', 'Gasoline');

-- passenger_booking table
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (1, 1);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (2, 1);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (3, 2);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (4, 2);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (5, 3);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (6, 3);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (7, 4);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (8, 4);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (9, 5);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (10, 5);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (1, 6);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (2, 6);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (3, 7);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (4, 7);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (5, 8);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (6, 8);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (7, 9);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (8, 9);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (9, 10);
INSERT INTO passenger_booking (passenger_passengerid, booking_bookingid) VALUES (10, 10);
