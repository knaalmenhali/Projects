CREATE OR REPLACE FUNCTION calculate_total_revenue
RETURN NUMBER
IS
    total_revenue NUMBER := 0;
BEGIN
    SELECT SUM(t.price)
    INTO total_revenue
    FROM booking b
    JOIN trip t ON b.trip_tripid = t.tripid
    WHERE b.status = 'Confirmed';

    RETURN total_revenue;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0; 
    WHEN OTHERS THEN
        RETURN NULL; 
END calculate_total_revenue;



CREATE OR REPLACE FUNCTION categorize_status(status VARCHAR2)
RETURN VARCHAR2
IS
BEGIN
    IF status = 'Confirmed' THEN
        RETURN 'Active';
    ELSIF status = 'Reserved' THEN
        RETURN 'Pending';
    ELSE
        RETURN 'Inactive';
    END IF;
END categorize_status;

