
package com.mycompany.advaooproject.dao;

import com.mycompany.advaooproject.Model.Bookings;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookingsDAO {
    private Connection conn;

    public BookingsDAO(Connection conn) {
        this.conn = conn;
    }

    public List<String> getAllBookings() throws SQLException {
        List<String> bookings = new ArrayList<>();
        String query = "SELECT * FROM Bookings";
        try (PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                bookings.add("Booking ID: " + rs.getString("BookingID") +
                             ", Passenger ID: " + rs.getString("PassengerID") +
                             ", Flight ID: " + rs.getString("FlightID") +
                             ", Booking Date: " + rs.getString("BookingDate"));
            }
        }
        return bookings;
    }
        // Add a new booking to the database
    public void addBooking(Bookings booking) throws SQLException {
        String query = "INSERT INTO Bookings (BookingID, PassengerID, FlightID, BookingDate) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, booking.getBookingID());
            pstmt.setString(2, booking.getPassengerID());
            pstmt.setString(3, booking.getFlightID());
            pstmt.setString(4, booking.getBookingDate());
            pstmt.executeUpdate();
        }
    }
}