package com.mycompany.advaooproject.Model;

public class InternationalFlight extends Flights {
    private boolean visaRequired;

    public InternationalFlight(String flightID, String destination, String departureTime, String arrivalTime, 
                               double price, String status, boolean visaRequired) {
        super(flightID, "Unknown", destination, departureTime, arrivalTime, price); 
        this.visaRequired = visaRequired;
    }

    public boolean isVisaRequired() {
        return visaRequired;
    }

    public void setVisaRequired(boolean visaRequired) {
        this.visaRequired = visaRequired;
    }

    @Override
    public String toString() {
        return super.toString() + ", Visa Required: " + (visaRequired ? "Yes" : "No");
    }
}

