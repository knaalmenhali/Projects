package com.mycompany.advaooproject.Model;

public class DomesticFlight extends Flights {
    private String baggageAllowance;

    public DomesticFlight(String flightID, String baggageAllowance, String departureCity, String arrivalCity,
                          String date, String time, double price, int availableSeats) {
        super(flightID, departureCity, arrivalCity, date, time, price);
        this.baggageAllowance = baggageAllowance;
    }

    public String getBaggageAllowance() {
        return baggageAllowance;
    }

    @Override
    public String toString() {
        return "Domestic Flight [ID: " + getFlightID() + ", Departure: " + getDepartureCity() +
               ", Arrival: " + getArrivalCity() + ", Date: " + getDate() + ", Time: " + getTime() +
               ", Price: $" + getPrice() + ", Seats: " + getAvailableSeats() +
               ", Baggage Allowance: " + baggageAllowance + "]";
    }

    public void setAvailableSeats(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


