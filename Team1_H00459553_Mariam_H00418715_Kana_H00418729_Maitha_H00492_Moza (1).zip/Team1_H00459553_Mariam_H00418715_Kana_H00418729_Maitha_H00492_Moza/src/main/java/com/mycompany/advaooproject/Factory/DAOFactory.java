
package com.mycompany.advaooproject.Factory;

import com.mycompany.advaooproject.dao.*;
import java.sql.Connection;

/**
 * 
 */
public class DAOFactory {

    public static Object createDAO(String type, Connection conn) {
        switch (type.toLowerCase()) {
            case "flights":
                return new FlightsDAO(conn);
            case "passengers":
                return new PassengerDAO(conn);
            case "bookings":
                return new BookingsDAO(conn);
            default:
                throw new IllegalArgumentException("Invalid DAO type: " + type);
        }
    }
}
