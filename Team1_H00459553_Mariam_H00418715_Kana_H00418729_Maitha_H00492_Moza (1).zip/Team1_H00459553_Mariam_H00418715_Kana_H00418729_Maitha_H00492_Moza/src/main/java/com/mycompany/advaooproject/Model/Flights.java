package com.mycompany.advaooproject.Model;

public class Flights implements Cloneable{
    private String flightID;
    private String departureCity;
    private String arrivalCity;
    private String date;
    private String time;
    private double price;
    private int availableSeats;
    private String id;
    private String destination;
    private double duration;

    public Flights(String flightID, String departureCity, String arrivalCity, String date, String time, double price) {
        this.flightID = flightID;
        this.departureCity = departureCity;
        this.arrivalCity = arrivalCity;
        this.date = date;
        this.time = time;
        this.price = price;
        this.availableSeats = availableSeats;
    }

    public String getFlightID() {
        return flightID;
    }

    public String getDepartureCity() {
        return departureCity;
    }

    public String getArrivalCity() {
        return arrivalCity;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public double getPrice() {
        return price;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    @Override
    public String toString() {
        return "Flight [ID: " + flightID + ", Departure: " + departureCity + 
               ", Arrival: " + arrivalCity + ", Date: " + date + ", Time: " + time +
               ", Price: $" + price + ", Seats: " + availableSeats + "]";
    }

    public String getDestination() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getDepartureTime() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getArrivalTime() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setStatus(String newStatus) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public Flights (String id, String destination, double duration) throws InvalidFlightDurationException {
    if (duration <= 0) {
        throw new InvalidFlightDurationException("Flight duration must be greater than 0.");
    }
    this.id = id;
    this.destination = destination;
    this.duration = duration;
}
    
    @Override
    public Flights clone() throws CloneNotSupportedException {
        return (Flights) super.clone();
    }
   
    
    public class FlightManagement extends AirlineAgency {

    public FlightManagement(String name, String location) {
        super("Flight Management", name, location); // Passing type explicitly as "Flight Management"
    }

    @Override
    public void provideServices() {
        System.out.println("Managing flight schedules and statuses.");
    }

    public void updateFlight(String flightID, String departure, String arrival) {
        System.out.println("Flight " + flightID + " updated with new departure and arrival times.");
    }

    public void cancelFlight(String flightID) {
        System.out.println("Flight " + flightID + " has been canceled.");
    }

    public void changeFlightStatus(String flightID, String status) {
        System.out.println("Flight " + flightID + " status changed to " + status + ".");
    }
}


}
