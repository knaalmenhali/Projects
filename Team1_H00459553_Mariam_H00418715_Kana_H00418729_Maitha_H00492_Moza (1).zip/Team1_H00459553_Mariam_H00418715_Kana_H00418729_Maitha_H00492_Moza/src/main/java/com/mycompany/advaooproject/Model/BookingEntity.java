
package com.mycompany.advaooproject.Model;

/**
 * Abstract base class for Booking Entities.
 */
public abstract class BookingEntity {
    private String id;

    public BookingEntity(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public abstract void displayDetails();
}
