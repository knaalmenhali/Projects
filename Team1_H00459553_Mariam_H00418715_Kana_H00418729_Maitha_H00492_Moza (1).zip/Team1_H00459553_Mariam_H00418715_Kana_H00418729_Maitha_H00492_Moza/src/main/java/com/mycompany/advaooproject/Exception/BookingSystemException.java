
package com.mycompany.advaooproject.Exception;

/**
 * Custom exception for booking system errors.
 */
public class BookingSystemException extends Exception {
    public BookingSystemException(String message) {
        super(message);
    }
}
