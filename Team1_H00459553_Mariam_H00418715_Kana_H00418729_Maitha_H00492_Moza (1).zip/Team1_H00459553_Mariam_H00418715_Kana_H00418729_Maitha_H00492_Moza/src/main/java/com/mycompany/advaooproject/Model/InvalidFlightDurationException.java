/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.advaooproject.Model;

/**
 *
 * @author mariambadhib
 */
public class InvalidFlightDurationException extends Exception {
 private String message;

    public InvalidFlightDurationException(String message) {
        this.message = message;
    }

    public String printMessage() {
        return "Invalid: " + message;
    }
}

