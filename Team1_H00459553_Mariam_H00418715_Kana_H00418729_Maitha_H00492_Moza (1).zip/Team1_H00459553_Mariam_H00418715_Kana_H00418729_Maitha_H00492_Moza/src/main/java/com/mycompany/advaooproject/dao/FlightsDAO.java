/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.advaooproject.dao;

import com.mycompany.advaooproject.Model.Flights;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kanna
 */
public class FlightsDAO {
    private Connection conn;

    public FlightsDAO(Connection conn) {
        this.conn = conn;
    }
public List<String> getAllFlights() throws SQLException {
    List<String> flights = new ArrayList<>();
    String query = "SELECT * FROM Flights";
    try (Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {
        while (rs.next()) {
            String flight = "Flight ID: " + rs.getString("FlightID") +
                            ", Origin: " + rs.getString("Origin") +
                            ", Destination: " + rs.getString("Destination") +
                            ", Departure: " + rs.getString("DepartureTime") +
                            ", Arrival: " + rs.getString("ArrivalTime");
            flights.add(flight);
        }
    }
    return flights;
}
public void addFlight(Flights flight) throws SQLException {
    String query = "INSERT INTO Flights (FlightID, Origin, Destination, DepartureTime, ArrivalTime) VALUES (?, ?, ?, ?, ?)";
    try (PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setString(1, flight.getFlightID());       // Correct getter for FlightID       // Correct getter for Origin
        pstmt.setString(2, flight.getDestination());    // Correct getter for Destination
        pstmt.setString(3, flight.getDepartureTime());  // Correct getter for DepartureTime
        pstmt.setString(4, flight.getArrivalTime());    // Correct getter for ArrivalTime
        pstmt.executeUpdate();
    }
}

    public Object findFlightByID(String flightID) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int addNewFlight(String flightID, double flightPrice) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int updateFlightPrice(String flightID, double flightPrice) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int deleteFlight(String flightID) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<String> findFlightsByPrice(double price) throws SQLException {
    List<String> flights = new ArrayList<>();
    String query = "SELECT * FROM Flights WHERE Price = ?";
    try (PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setDouble(1, price);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            String flight = "Flight ID: " + rs.getString("FlightID") +
                            ", Origin: " + rs.getString("Origin") +
                            ", Destination: " + rs.getString("Destination") +
                            ", Departure: " + rs.getString("DepartureTime") +
                            ", Arrival: " + rs.getString("ArrivalTime") +
                            ", Price: " + rs.getDouble("Price");
            flights.add(flight);
        }
    }
    return flights;
}

    public int reserveFlight(String flightID) throws SQLException {
    String query = "UPDATE Flights SET Reserved = 1 WHERE FlightID = ? AND Reserved = 0"; // Assuming a Reserved column exists
    try (PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setString(1, flightID);
        return pstmt.executeUpdate(); // Returns 1 if reservation is successful
    }
    }
}
    
    



