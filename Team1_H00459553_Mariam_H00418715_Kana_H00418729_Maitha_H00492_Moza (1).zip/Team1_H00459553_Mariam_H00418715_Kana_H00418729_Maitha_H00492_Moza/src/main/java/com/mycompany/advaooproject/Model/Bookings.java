package com.mycompany.advaooproject.Model;

/**
 * Represents a Booking in the system.
 */
public class Bookings {
    private String bookingID;
    private String passengerID;
    private String flightID;
    private String bookingDate;

    // Constructor
    public Bookings(String bookingID, String passengerID, String flightID, String bookingDate) {
        this.bookingID = bookingID;
        this.passengerID = passengerID;
        this.flightID = flightID;
        this.bookingDate = bookingDate;
    }

    // Getter and Setter for bookingID
    public String getBookingID() {
        return bookingID;
    }

    public void setBookingID(String bookingID) {
        this.bookingID = bookingID;
    }

    // Getter and Setter for passengerID
    public String getPassengerID() {
        return passengerID;
    }

    public void setPassengerID(String passengerID) {
        this.passengerID = passengerID;
    }

    // Getter and Setter for flightID
    public String getFlightID() {
        return flightID;
    }

    public void setFlightID(String flightID) {
        this.flightID = flightID;
    }

    // Getter and Setter for bookingDate
    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    // Override toString method for better output formatting
    @Override
    public String toString() {
        return "Booking [BookingID=" + bookingID + ", PassengerID=" + passengerID +
               ", FlightID=" + flightID + ", BookingDate=" + bookingDate + "]";
    }
}
