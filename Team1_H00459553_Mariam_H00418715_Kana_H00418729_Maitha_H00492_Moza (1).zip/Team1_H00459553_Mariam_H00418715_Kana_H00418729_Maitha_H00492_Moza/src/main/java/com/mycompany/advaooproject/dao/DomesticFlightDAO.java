/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.advaooproject.dao;

/**
 *
 * @author mariambadhib
 */
import com.mycompany.advaooproject.Model.DomesticFlight;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DomesticFlightDAO {
    private Connection conn;

    public DomesticFlightDAO(Connection conn) {
        this.conn = conn;
    }

    // Add a flight
    public void addFlight(DomesticFlight flight) throws SQLException {
        String query = "INSERT INTO DomesticFlights (flightID, baggageAllowance, departureCity, arrivalCity, date, time, price, availableSeats) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, flight.getFlightID());
            pstmt.setString(2, flight.getBaggageAllowance());
            pstmt.setString(3, flight.getDepartureCity());
            pstmt.setString(4, flight.getArrivalCity());
            pstmt.setString(5, flight.getDate());
            pstmt.setString(6, flight.getTime());
            pstmt.setDouble(7, flight.getPrice());
            pstmt.setInt(8, flight.getAvailableSeats());
            pstmt.executeUpdate();
        }
    }

    // Find a flight by ID
    public DomesticFlight findFlightByID(String flightID) throws SQLException {
        String query = "SELECT * FROM DomesticFlights WHERE flightID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, flightID);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new DomesticFlight(
                            rs.getString("flightID"),
                            rs.getString("baggageAllowance"),
                            rs.getString("departureCity"),
                            rs.getString("arrivalCity"),
                            rs.getString("date"),
                            rs.getString("time"),
                            rs.getDouble("price"),
                            rs.getInt("availableSeats")
                    );
                }
            }
        }
        return null;
    }

    // Update a flight
    public void updateFlight(DomesticFlight flight) throws SQLException {
        String query = "UPDATE DomesticFlights SET baggageAllowance = ?, departureCity = ?, arrivalCity = ?, date = ?, time = ?, price = ?, availableSeats = ? WHERE flightID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, flight.getBaggageAllowance());
            pstmt.setString(2, flight.getDepartureCity());
            pstmt.setString(3, flight.getArrivalCity());
            pstmt.setString(4, flight.getDate());
            pstmt.setString(5, flight.getTime());
            pstmt.setDouble(6, flight.getPrice());
            pstmt.setInt(7, flight.getAvailableSeats());
            pstmt.setString(8, flight.getFlightID());
            pstmt.executeUpdate();
        }
    }

    // Delete a flight
    public void deleteFlight(String flightID) throws SQLException {
        String query = "DELETE FROM DomesticFlights WHERE flightID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, flightID);
            pstmt.executeUpdate();
        }
    }

    // Retrieve all flights
    public List<DomesticFlight> getAllFlights() throws SQLException {
        List<DomesticFlight> flights = new ArrayList<>();
        String query = "SELECT * FROM DomesticFlights";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                flights.add(new DomesticFlight(
                        rs.getString("flightID"),
                        rs.getString("baggageAllowance"),
                        rs.getString("departureCity"),
                        rs.getString("arrivalCity"),
                        rs.getString("date"),
                        rs.getString("time"),
                        rs.getDouble("price"),
                        rs.getInt("availableSeats")
                ));
            }
        }
        return flights;
    }
}