/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.advaooproject.Model;

import java.util.ArrayList;

/**
 *
 * @author kanna
 */
public class BookingGeneric<T> {

    private ArrayList<T> tList;

    public BookingGeneric() {
        tList = new ArrayList<>();
    }

    public void add(T t) {
        tList.add(t);
    }

    public T get(int i) {
        return tList.get(i);
    }

    public int count() {
        return tList.size();
    }

    public void printAll() {
        for (T item : tList) {
            System.out.println(item);
        }
    }
}
