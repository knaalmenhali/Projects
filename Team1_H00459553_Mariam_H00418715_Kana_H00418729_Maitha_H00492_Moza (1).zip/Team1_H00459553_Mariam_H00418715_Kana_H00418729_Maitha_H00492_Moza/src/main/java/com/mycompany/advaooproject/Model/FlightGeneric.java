/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.advaooproject.Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kanna
 */
class FlightGeneric<T> {

    private ArrayList<T> flightList;

    public FlightGeneric() {
        flightList = new ArrayList<>();
    }

    public void add(T flight) {
        flightList.add(flight);
    }

    public T get(int index) {
        return flightList.get(index);
    }

    public int count() {
        return flightList.size();
    }

    public void printAll() {
        for (T flight : flightList) {
            System.out.println(flight);
        }
    }
}
