

package com.mycompany.advaooproject.Model;

import java.util.ArrayList;
import java.util.List;

public abstract class AirlineAgency {
    private String type;
    private String name;
    private String location;
    private List<Passengers> passengers;

    // Constructor
    public AirlineAgency(String type, String name, String location) {
        this.type = type;
        this.name = name;
        this.location = location;
        this.passengers = new ArrayList<>();
    }

    // Getter for name
    public String getName() {
        return name;
    }
    
    
    public void setName(String name) {
        this.name = name;
    }

    // Getter for location
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public List<Passengers> getpassengers() {
        return passengers;
    }



    // Method to add a passenger
    public void addPassenger(Passengers passenger) {
        if (passenger != null) {
            passengers.add(passenger);
            System.out.println("Passenger added: " + passenger);
        } else {
            System.out.println("Cannot add null passenger!");
        }
    }

    // Provide services
    public void provideServices() {
        System.out.println("Providing services at " + name + " located in " + location);
        for (Passengers passenger : passengers) {
            System.out.println("Serving Passenger: " + passenger);
        }
    }

    @Override
    public String toString() {
        return "AirlineAgency{" +
                "type='" + type + '\'' +
                ", name='" + name + '\'' +
                ", location='" + location + '\'' +
                '}';
    }
}
