
package com.mycompany.advaooproject.Model;

public interface FlightOperations {

    public void reserveFlight(Flights flight);

    public String checkFlightStatus(String flightID);

    public void cancelFlight(Flights flight);
}
