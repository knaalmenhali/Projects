package com.mycompany.advaooproject.Model;

import java.util.ArrayList;
import java.util.List;

public class FlightManagement extends AirlineAgency {

    // A list to store flights (acting as a database for simplicity)
    private List<Flights> flightList;

    // Constructor
    public FlightManagement(String name, String location) {
        super("Flight Management", name, location); // Passing type explicitly as "Flight Management"
        this.flightList = new ArrayList<>(); // Initialize flight list
    }

    // Method to add a new flight
    public void addFlight(Flights flight) {
        if (flight != null) {
            flightList.add(flight);
            System.out.println("Flight added successfully: " + flight);
        } else {
            System.out.println("Flight cannot be null!");
        }
    }

    // Method to update a flight's status by ID
    public void updateFlight(String flightID, String newStatus) {
        if (flightID == null || newStatus == null || flightID.isEmpty()) {
            System.out.println("Invalid flight ID or status!");
            return;
        }

        for (Flights flight : flightList) {
            if (flight.getFlightID().equals(flightID)) {
                flight.setStatus(newStatus); // Ensure setStatus exists in Flights
                System.out.println("Flight updated successfully: " + flight);
                return;
            }
        }

        System.out.println("Flight with ID " + flightID + " not found!");
    }

    // Method to delete a flight by ID
    public void deleteFlight(String flightID) {
        if (flightID == null || flightID.isEmpty()) {
            System.out.println("Invalid flight ID!");
            return;
        }

        for (int i = 0; i < flightList.size(); i++) {
            if (flightList.get(i).getFlightID().equals(flightID)) {
                Flights removedFlight = flightList.remove(i);
                System.out.println("Flight deleted successfully: " + removedFlight);
                return;
            }
        }

        System.out.println("Flight with ID " + flightID + " not found!");
    }

    // Override the provideServices method
    @Override
    public void provideServices() {
        System.out.println(getName() + " provides comprehensive flight management services.");
    }

    // Method to list all flights (for debugging or display purposes)
    public void listAllFlights() {
        if (flightList.isEmpty()) {
            System.out.println("No flights available!");
        } else {
            System.out.println("Available Flights:");
            for (Flights flight : flightList) {
                System.out.println(flight);
            }
        }
    }
}

