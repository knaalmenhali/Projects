/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.advaooproject.dao;

/**
 *
 * @author mariambadhib
 */

import com.mycompany.advaooproject.view.InternationalFlight;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InternationalFlightDAO {
    private Connection conn;

    public InternationalFlightDAO(Connection conn) {
        this.conn = conn;
    }

    public InternationalFlightDAO() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Add a new flight
    public void addFlight(InternationalFlight flight) throws SQLException {
        String query = "INSERT INTO InternationalFlights (FlightID, AirlineName, DepartureCountry, ArrivalCountry, Date, Time, TicketPrice, AvailableSeats, Duration) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, flight.getFlightID());
            pstmt.setString(2, flight.getAirlineName());
            pstmt.setString(3, flight.getDepartureCountry());
            pstmt.setString(4, flight.getArrivalCountry());
            pstmt.setString(5, flight.getDate());
            pstmt.setString(6, flight.getTime());
            pstmt.setDouble(7, flight.getTicketPrice());
            pstmt.setInt(8, flight.getAvailableSeats());
            pstmt.setString(9, flight.getDuration());
            pstmt.executeUpdate();
        }
    }

    // Find a flight by ID
    public InternationalFlight findFlightByID(String flightID) throws SQLException {
        String query = "SELECT * FROM InternationalFlights WHERE FlightID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, flightID);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new InternationalFlight(
                        rs.getString("FlightID"),
                        rs.getString("AirlineName"),
                        rs.getString("DepartureCountry"),
                        rs.getString("ArrivalCountry"),
                        rs.getString("Date"),
                        rs.getString("Time"),
                        rs.getDouble("TicketPrice"),
                        rs.getInt("AvailableSeats"),
                        rs.getString("Duration")
                );
            }
        }
        return null;
    }

    // Update an existing flight
    public void updateFlight(InternationalFlight flight) throws SQLException {
        String query = "UPDATE InternationalFlights SET AirlineName = ?, DepartureCountry = ?, ArrivalCountry = ?, Date = ?, Time = ?, TicketPrice = ?, AvailableSeats = ?, Duration = ? WHERE FlightID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, flight.getAirlineName());
            pstmt.setString(2, flight.getDepartureCountry());
            pstmt.setString(3, flight.getArrivalCountry());
            pstmt.setString(4, flight.getDate());
            pstmt.setString(5, flight.getTime());
            pstmt.setDouble(6, flight.getTicketPrice());
            pstmt.setInt(7, flight.getAvailableSeats());
            pstmt.setString(8, flight.getDuration());
            pstmt.setString(9, flight.getFlightID());
            pstmt.executeUpdate();
        }
    }

    // Delete a flight
    public void deleteFlight(String flightID) throws SQLException {
        String query = "DELETE FROM InternationalFlights WHERE FlightID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, flightID);
            pstmt.executeUpdate();
        }
    }

    // Get all flights
    public List<InternationalFlight> getAllFlights() throws SQLException {
    List<InternationalFlight> flights = new ArrayList<>();
    String query = "SELECT * FROM InternationalFlights";
    try (Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {
        while (rs.next()) {
            flights.add(new InternationalFlight(
                rs.getString("FlightID"),
                rs.getString("AirlineName"),
                rs.getString("DepartureCountry"),
                rs.getString("ArrivalCountry"),
                rs.getString("Date"),
                rs.getString("Time"),
                rs.getDouble("TicketPrice"),
                rs.getInt("AvailableSeats"),
                rs.getString("Duration")
            ));
        }
    }
    return flights;
}

    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
