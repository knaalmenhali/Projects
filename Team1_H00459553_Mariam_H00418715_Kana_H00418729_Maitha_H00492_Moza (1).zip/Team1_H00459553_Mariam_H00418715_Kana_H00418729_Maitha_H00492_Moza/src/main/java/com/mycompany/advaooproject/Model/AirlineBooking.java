/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.advaooproject.Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mariambadhib
 */
public class AirlineBooking {
    public static void main(String[] args) throws CloneNotSupportedException {
        
        
        // Generic list for flights
        List<Flights> flightList = new ArrayList<>();

        // Adding Domestic Flights
        flightList.add(new DomesticFlight("DF001", "20kg", "New York", "Boston", "2024-11-20", "08:00", 500.0, 150));
        flightList.add(new DomesticFlight("DF002", "25kg", "Los Angeles", "San Francisco", "2024-11-25", "14:00", 600.0, 200));

        // Adding International Flights
        flightList.add(new InternationalFlight("IF001", "London", "2024-11-22 10:00", "2024-11-22 20:00", 1000.0, "Scheduled", true));
        flightList.add(new InternationalFlight("IF002", "Tokyo", "2024-12-05 16:00", "2024-12-06 08:00", 1200.0, "Scheduled", true));

        // Displaying flight information
        System.out.println("Flight List:");
        for (Flights flight : flightList) {
            System.out.println(flight);
        }

        // Creating Passengers
        Passengers p1 = new Passengers("P001", "Jane Doe", "jane.doe@example.com");
        
        // Clone the passenger
        Passengers p2 = p1.clone();

        // Modify the cloned passenger's details using setters
        p2.setPassengerID("P002");
        p2.setName("Robert Lee");
        p2.setEmail("robert.lee@example.com");

        
        // Displaying passenger information
        System.out.println("\nPassenger List:");
        System.out.println(p1);
        System.out.println(p2);

        // Creating airline agency using a factory
        AirlineAgency agency = AirlineAgencyFactory.createAgency("management", "Skyline Management", "Abu Dhabi");

        if (agency != null) {
            agency.addPassenger(p1);
            agency.addPassenger(p2);
            agency.provideServices();
        } else {
            System.out.println("Failed to create AirlineAgency.");
        }
    }
}


