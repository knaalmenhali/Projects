package com.mycompany.advaooproject.Model;

public class Passengers implements Cloneable {
    private String passengerID;
    private String name;
    private String email;
    private Object Flights;
    private Object BookingManagement;

    // Constructor
    public Passengers(String passengerID, String name, String email) {
        this.passengerID = passengerID;
        this.name = name;
        this.email = email;
    }

    // Getters and Setters
    public String getPassengerID() {
        return passengerID;
    }

    public void setPassengerID(String passengerID) {
        this.passengerID = passengerID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Passenger [ID=" + passengerID + ", Name=" + name + ", Email=" + email + "]";
    }

    // Overriding clone method
    @Override
    public Passengers clone() {
        try {
            return (Passengers) super.clone(); // Call Object's clone method
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Cloning not supported for Passengers", e);
        }
    }

    public Object getContact() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Object getNationality() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Object getReservedFlights() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
