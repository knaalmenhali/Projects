
package com.mycompany.advaooproject.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton for database connection.
 */
public class DBConnection {
    private static Connection conn;

    private DBConnection() {}

    public static Connection getInstance() throws SQLException {
        if (conn == null) {
            conn = DriverManager.getConnection("jdbc:sqlite:/mnt/data/AirlineManagement.db");
            String url = null;
            conn = DriverManager.getConnection(url);
        }
        return conn;
    }
}
