/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.advaooproject.dao;

/**
 *
 * @author mariambadhib
 */
import com.mycompany.advaooproject.Model.AirlineAgent;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AirlineAgentDAO {
    private Connection connection;

    public AirlineAgentDAO(Connection connection) {
        this.connection = connection;
    }

    public void addAgent(AirlineAgent agent) throws SQLException {
        String sql = "INSERT INTO AirlineAgent (agentID, name, contactDetails, assignedFlights) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, agent.getAgentID());
            statement.setString(2, agent.getName());
            statement.setString(3, agent.getContactDetails());
            statement.setString(4, agent.getAssignedFlights());
            statement.executeUpdate();
        }
    }

    public void updateAgent(AirlineAgent agent) throws SQLException {
        String sql = "UPDATE AirlineAgent SET name = ?, contactDetails = ?, assignedFlights = ? WHERE agentID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, agent.getName());
            statement.setString(2, agent.getContactDetails());
            statement.setString(3, agent.getAssignedFlights());
            statement.setInt(4, agent.getAgentID());
            statement.executeUpdate();
        }
    }

    public void deleteAgent(int agentID) throws SQLException {
        String sql = "DELETE FROM AirlineAgent WHERE agentID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, agentID);
            statement.executeUpdate();
        }
    }

    public AirlineAgent findAgentByID(int agentID) throws SQLException {
        String sql = "SELECT * FROM AirlineAgent WHERE agentID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, agentID);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new AirlineAgent(
                        resultSet.getInt("agentID"),
                        resultSet.getString("name"),
                        resultSet.getString("contactDetails"),
                        resultSet.getString("assignedFlights")
                    );
                }
            }
        }
        return null;
    }

    public List<AirlineAgent> getAllAgents() throws SQLException {
        List<AirlineAgent> agents = new ArrayList<>();
        String sql = "SELECT * FROM AirlineAgent";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                agents.add(new AirlineAgent(
                    resultSet.getInt("agentID"),
                    resultSet.getString("name"),
                    resultSet.getString("contactDetails"),
                    resultSet.getString("assignedFlights")
                ));
            }
        }
        return agents;
    }
}
