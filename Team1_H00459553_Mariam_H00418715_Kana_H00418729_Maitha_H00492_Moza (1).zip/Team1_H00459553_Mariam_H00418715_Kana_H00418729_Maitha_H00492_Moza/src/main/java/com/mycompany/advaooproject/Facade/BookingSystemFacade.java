/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.advaooproject.Facade;

import com.mycompany.advaooproject.Model.Flights;
import com.mycompany.advaooproject.Model.Passengers;
import com.mycompany.advaooproject.Model.Bookings;
import com.mycompany.advaooproject.dao.FlightsDAO;
import com.mycompany.advaooproject.dao.PassengerDAO;
import com.mycompany.advaooproject.dao.BookingsDAO;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * 
 */
public class BookingSystemFacade {

    private final FlightsDAO flightsDAO;
    private final PassengerDAO passengerDAO;
    private final BookingsDAO bookingsDAO;

    public BookingSystemFacade(Connection conn) {
        this.flightsDAO = new FlightsDAO(conn);
        this.passengerDAO = new PassengerDAO(conn);
        this.bookingsDAO = new BookingsDAO(conn);
    }

    public void addFlight(Flights flight) throws SQLException {
        flightsDAO.addFlight(flight);
    }

    public void addPassenger(Passengers passenger) throws SQLException {
        passengerDAO.addPassenger(passenger);
    }

    public void addBooking(Bookings booking) throws SQLException {
        bookingsDAO.addBooking(booking);
    }

    public List<String> getAllFlights() throws SQLException {
        return flightsDAO.getAllFlights();
    }

    public List<Passengers> getAllPassengers() throws SQLException {
        return passengerDAO.getAllPassengers();
    }

    public List<String> getAllBookings() throws SQLException {
        return bookingsDAO.getAllBookings();
    }
}