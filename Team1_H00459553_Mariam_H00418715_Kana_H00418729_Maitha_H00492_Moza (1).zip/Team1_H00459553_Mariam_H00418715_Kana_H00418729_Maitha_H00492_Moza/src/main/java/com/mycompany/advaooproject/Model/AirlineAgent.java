
package com.mycompany.advaooproject.Model;

public class AirlineAgent {
    private int agentID;
    private String name;
    private String contactDetails;
    private String assignedFlights;

    public AirlineAgent(int agentID, String name, String contactDetails, String assignedFlights) {
        this.agentID = agentID;
        this.name = name;
        this.contactDetails = contactDetails;
        this.assignedFlights = assignedFlights;
    }

    public int getAgentID() {
        return agentID;
    }

    public void setAgentID(int agentID) {
        this.agentID = agentID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(String contactDetails) {
        this.contactDetails = contactDetails;
    }

    public String getAssignedFlights() {
        return assignedFlights;
    }

    public void setAssignedFlights(String assignedFlights) {
        this.assignedFlights = assignedFlights;
    }
}