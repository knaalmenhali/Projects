package com.mycompany.advaooproject.Model;

import static com.sun.source.util.DocTrees.instance;
import java.util.ArrayList;
import java.util.List;

public class BookingManagement extends AirlineAgency {
    
        private static BookingManagement instance;

    // List to store bookings (simulating a database)
    private List<Bookings> bookings;

    // Constructor
    public BookingManagement(String name, String location) {
        super("Booking Management", name, location); // Pass the type explicitly
        this.bookings = new ArrayList<>(); // Initialize the booking list
    }
    
    public static BookingManagement getInstance(String name, String location) {
        if (instance == null) {
            instance = new BookingManagement(name, location);
        }
        return instance;
    }


    // Method to create a booking
    public void createBooking(String bookingID, String passengerID, String flightID, String bookingDate) {
        if (bookingID == null || passengerID == null || flightID == null || bookingDate == null || 
            bookingID.isEmpty() || passengerID.isEmpty() || flightID.isEmpty() || bookingDate.isEmpty()) {
            System.out.println("Invalid booking details!");
            return;
        }

        Bookings newBooking = new Bookings(bookingID, passengerID, flightID, bookingDate);
        bookings.add(newBooking);
        System.out.println("Booking created successfully: " + newBooking);
    }

    // Method to update a booking's date
    public void updateBooking(String bookingID, String newBookingDate) {
        if (bookingID == null || newBookingDate == null || bookingID.isEmpty()) {
            System.out.println("Invalid booking ID or booking date!");
            return;
        }

        for (Bookings booking : bookings) {
            if (booking.getBookingID().equals(bookingID)) {
                booking.setBookingDate(newBookingDate); // Update booking date
                System.out.println("Booking updated successfully: " + booking);
                return;
            }
        }

        System.out.println("Booking with ID " + bookingID + " not found!");
    }

    // Method to cancel a booking
    public void cancelBooking(String bookingID) {
        if (bookingID == null || bookingID.isEmpty()) {
            System.out.println("Invalid booking ID!");
            return;
        }

        for (int i = 0; i < bookings.size(); i++) {
            if (bookings.get(i).getBookingID().equals(bookingID)) {
                Bookings removedBooking = bookings.remove(i);
                System.out.println("Booking canceled successfully: " + removedBooking);
                return;
            }
        }

        System.out.println("Booking with ID " + bookingID + " not found!");
    }

    // Override the provideServices method
    @Override
    public void provideServices() {
        System.out.println(getName() + " offers comprehensive booking management services.");
    }

    // Method to list all bookings (for debugging or display purposes)
    public void listAllBookings() {
        if (bookings.isEmpty()) {
            System.out.println("No bookings available!");
        } else {
            System.out.println("Available Bookings:");
            for (Bookings booking : bookings) {
                System.out.println(booking);
            }
        }
    }
}
