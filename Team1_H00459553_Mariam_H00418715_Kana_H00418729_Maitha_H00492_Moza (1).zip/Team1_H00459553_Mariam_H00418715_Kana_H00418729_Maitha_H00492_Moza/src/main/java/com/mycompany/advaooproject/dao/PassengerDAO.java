package com.mycompany.advaooproject.dao;

import com.mycompany.advaooproject.Model.Passengers;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PassengerDAO {
    private Connection conn;

    public PassengerDAO(Connection conn) {
        this.conn = conn;
    }

    // Retrieve all passengers
    public List<Passengers> getAllPassengers() throws SQLException {
        List<Passengers> passengers = new ArrayList<>();
        String query = "SELECT * FROM Passengers";
        try (PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                Passengers passenger = new Passengers(
                    rs.getString("PassengerID"),
                    rs.getString("Name"),
                    rs.getString("Contact"));
                passengers.add(passenger);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving passengers: " + e.getMessage());
            throw e;
        }
        return passengers;
    }

    // Add a new passenger
    public void addPassenger(Passengers passenger) throws SQLException {
        String query = "INSERT INTO Passengers (PassengerID, Name, Contact, Nationality, ReservedFlights) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, passenger.getPassengerID());
            pstmt.setString(2, passenger.getName());
            pstmt.setString(3, (String) passenger.getContact());
            pstmt.setString(4, (String) passenger.getNationality());
            pstmt.setString(5, (String) passenger.getReservedFlights());
            pstmt.executeUpdate();
        }
    }

    // Find a passenger by ID
    public Passenger findPassengerByID(String passengerID) throws SQLException {
        String query = "SELECT * FROM Passengers WHERE PassengerID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, passengerID);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Passenger(
                        rs.getString("PassengerID"),
                        rs.getString("Name"),
                        rs.getString("Contact"),
                        rs.getString("Nationality"),
                        rs.getString("ReservedFlights")
                    );
                }
            }
        }
        return null; // Passenger not found
    }

    // Update an existing passenger
    public void updatePassenger(Passenger passenger) throws SQLException {
        String query = "UPDATE Passengers SET Name = ?, Contact = ?, Nationality = ?, ReservedFlights = ? WHERE PassengerID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, passenger.getName());
            pstmt.setString(2, passenger.getContact());
            pstmt.setString(3, passenger.getNationality());
            pstmt.setString(4, passenger.getReservedFlights());
            pstmt.setString(5, passenger.getPassengerID());
            pstmt.executeUpdate();
        }
    }

    // Delete a passenger by ID
    public void deletePassenger(String passengerID) throws SQLException {
        String query = "DELETE FROM Passengers WHERE PassengerID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, passengerID);
            pstmt.executeUpdate();
        }
    }

    public void updatePassenger(Passengers passenger) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static class Passenger {

        public Passenger(String string, String string1, String string2, String string3, String string4) {
        }

        public String getName() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public String getContact() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public String getNationality() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public String getReservedFlights() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String getPassengerID() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public void setReservedFlights(String reservedFlights) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }



    
}
