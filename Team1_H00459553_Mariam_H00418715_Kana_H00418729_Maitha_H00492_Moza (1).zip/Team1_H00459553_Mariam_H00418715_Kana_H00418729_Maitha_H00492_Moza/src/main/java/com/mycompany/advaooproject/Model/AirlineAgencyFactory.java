package com.mycompany.advaooproject.Model;

public class AirlineAgencyFactory {
    public static AirlineAgency createAgency(String type, String name, String location) {
        if ("management".equalsIgnoreCase(type)) {
            return new ManagementAgency(name, location);
        }
        return null; // Add more cases if needed
    }
}
