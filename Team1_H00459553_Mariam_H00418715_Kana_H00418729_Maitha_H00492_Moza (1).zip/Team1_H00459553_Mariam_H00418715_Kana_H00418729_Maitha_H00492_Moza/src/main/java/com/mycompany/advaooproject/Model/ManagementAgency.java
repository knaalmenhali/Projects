package com.mycompany.advaooproject.Model;

public class ManagementAgency extends AirlineAgency {

    // Constructor
    public ManagementAgency(String name, String location) {
        super("Management", name, location); // Passing "Management" as the type
    }

    @Override
    public void provideServices() {
        System.out.println(getName() + " (Management) is providing management services at " + getLocation());
    }
}
